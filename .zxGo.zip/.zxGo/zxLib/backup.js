0. setkey
1. upimage
2. upcover
3. upname
4. upbio
5. promote
6. demote
7. addadmin
8. deladmin
9. msgleave
10. msgunban
11. msgready
12. msgwelcome
13. stcleave
14. stcunban
15. stcrespon
16. stckick
17. clearcontacts
18. clearadmin
19. leaveall
20. acceptall
21. addassist
22. delassist
23. addajs
24. delajs
25. reload
26. shutdown
27. upheader
28. setlimiter
29. change
30. out
31. bye
32. join
33. inv
34. limitout
35. groups
36. gurl
37. gnuke
38. ginvite
39. joinurl
40. clearban
41. clearchat
42. clearstaff
43. cleanse
44. cancelall
45. unsend
46. kick
47. sikat
48. nk
49. contacts
50. status
51. listhere
52. banlist
53. managers
54. promote
55. demote
56. addstaff
57. delstaff
58. notag
59. reply
60. welcome
61. setinv
62. forceall
63. ajs
64. warmode
65. limiter
66. stabilizer
67. nukejoin
68. blockurl
69. blockjoin
70. blockgname
71. blockinvite
72. lockmember
73. killban
74. help
75. ready
76. speed
77. speeds
78. time
79. runtime
80. myuid
81. mygrade
82. about
83. log
84. set
85. refresh
86. cleartrash
87. fs
88. getuid
89. getsmule
90. addgif
91. croot
92. ourl
93. curl
94. groupinfo
95. lurk
96. say
97. finishim
98. bypass
99. mybots


func backupAssist(lc string,pl string,kr string){
	runtime.GOMAXPROCS(cpu)
	_, found := groupLock[lc]
	if found == true{
		kr := []string{}
		for i := range groupLock[lc] {
			kr = append(kr, groupLock[lc][i])
		}
		go func(){DeleteOtherFromChat(lc, []string{pl})}()
		go func(){InviteIntoChat(lc, kr)}()
		go func(){appendBl(pl)}()
	}
}

func backupManagers(lc string,pl string,kr string){
	runtime.GOMAXPROCS(cpu)
	cek := GetChat([]string{lc}, true, false)
	midMembers := cek.Chat[0].Extra.GroupExtra.MemberMids
	_, foundGC := midMembers[myself]
	if foundGC == true{
		go func(){DeleteOtherFromChat(lc, []string{pl})}()
		go func(){InviteIntoChat(lc, []string{kr})}()
		go func(){appendBl(pl)}()
	}
}

╭──────────────
│╭─⋤•Main stats•⋥
│├• Kick ban : Ready
│╰• Add stat : Allow
│╭──•>>>>>>>>>>>─
│├─⋤• Assist V1 •⋥
│├>>─Kick • ✓─<<
│├>>─Add • ✘─<<
│├─⋤• Assist V2 •⋥
│├>>─Kick • ✓─<<
│├>>─Add • ✘─<<
│├─⋤• Assist V3 •⋥
│├>>─Kick • ✓─<<
│├>>─Add • ✘─<<
│├─⋤• Assist V4 •⋥
│├>>─Kick • ✓─<<
│├>>─Add • ✘─<<
│├─⋤• Assist V5 •⋥
│├>>─Kick • ✓─<<
│├>>─Add • ✘─<<
│├─⋤• Assist V6 •⋥
│├>>─Kick • ✓─<<
│├>>─Add • ✘─<<
│╰──•>>>>>>>>>>>─
╰──────────────

╭──────────────
│╭─⋤•Main stats•⋥
│├• Kickban : Ready
│╰• Add sts : Allow
│╭──•>>>>>>>>>>>─
│├─•⋤Assist-V1⋥•
│├•> Kickban : ✘
│├•> Add sts : ✓
│├─•⋤Assist-V2⋥•
│├•> Kickban : ✓
│├•> Add sts : ✘
│├─•⋤Assist-V3⋥•
│├•> Kickban : ✘
│├•> Add sts : ✓
│├─•⋤Assist-V4⋥•
│├•> Kickban : ✓
│├•> Add sts : ✘
│├─•⋤Assist-V5⋥•
│├•> Kickban : ✘
│├•> Add sts : ✓
│├─•⋤Assist-V6⋥•
│├•> Kickban : ✓
│├•> Add sts : ✘
│╰──•>>>>>>>>>>>─
╰──────────────

