
package main

import (
	"context"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"strings"
	"strconv"
	"os"
	"os/exec"
	"net"
	"net/http"
	"sync"
	"time"
	"runtime"
	"math/rand"
	"github.com/leekchan/timeutil"
	"github.com/shirou/gopsutil/v3/mem"
	core "./zxLib/LINE"
	thrift "./zxLib/thrift"
)
var Seq int32
var argsRaw = os.Args
var botStart = time.Now()
var Configs configs
var cpu int = 10
var timRespon int = 0
var targetNumber int = 0
var stabilizer int = 1
var duedatecount int = 0
var getStickerRespon int = 0
var getStickerRein int = 0
var getStickerBye int = 0
var getStickerUnban int = 0
var getStickerKick int = 0
var updatePicture int = 0
var updatePicture2 int = 0
var updateCover int = 0
var updateCover2 int = 0
var autoPurge int = 1
var antipurge int = 1
var agresifMode int = 0
var detectBL int = 0
var limiterset int = 0
var zxBots int = 0
var trial bool = false
var jsonName string = ""
var myip string = "118.27.109.169"
var port string = "127.0.0.1:51000"
var zxApp string = "ANDROIDLITE\t2.17.0\tAndroid OS\t6.0.1"
var rname string = ""
var sname string = ""
var proQr = make(map[string]int)
var proInvite = make(map[string]int)
var proName = make(map[string]int)
var denyTag = make(map[string]int)
var kickLock = make(map[string]int)
var joinLock = make(map[string]int)
var welcome = make(map[string]int)
var saveGname = make(map[string]string)
var chatTemp = make(map[string][]string)
var checkRead = make(map[string]int)
var promoteadmin = make(map[string]int)
var promotestaff = make(map[string]int)
var demoteadmin = make(map[string]int)
var demotestaff = make(map[string]int)
var readerTemp = make(map[string][]string)
var msgTemp = make(map[string][]string)
var groupLock = make(map[string][]string)
var temp_flood = make(map[string]int)
var commands = []string{"setkey","upimage","upcover","upname","upbio","promote","demote","addadmin","deladmin","msgleave","msgunban","msgready","msgwelcome","stcleave","stcunban","stcrespon","stckick","clearcontacts","clearadmin","leaveall","acceptall","addassist","delassist","addajs","delajs","reload","shutdown","upheader","setlimiter","change","out","bye","join","inv","limitout","groups","gurl","gnuke","ginvite","joinurl","clearban","clearchat","clearstaff","cleanse","cancelall","unsend","kick","sikat","nk","contacts","status","listhere","banlist","managers","promote","demote","addstaff","delstaff","notag","reply","welcome","setinv","forceall","ajs","warmode","limiter","stabilizer","nukejoin","blockurl","blockjoin","blockgname","blockinvite","lockmember","killban","help","ready","speed","speeds","time","runtime","myuid","mygrade","about","log","set","refresh","cleartrash","fs","getuid","getsmule","addgif","croot","ourl","curl","groupinfo","lurk","say","finishim","bypass","mybots"}
var bans = []string{}
var zbans = []string{}
var zxTroops = []string{}
var limitoutTemp = []string{}
var mystaff = []string{}
var myadmin = []string{}
var myteam = []string{}
var ryan string = "uf760442fba810631a22a73ff4ba47245"
var mycreator = []string{"uf760442fba810631a22a73ff4ba47245"}
var myassist = []string{}
var myantijs = []string{}
var targetbc = []string{}
var targetViewLimit = []string{}
var zxTeam = []string{}
var stkid string = ""
var stkpkgid string = ""
var stkid2 string = ""
var stkpkgid2 string = ""
var stkid3 string = ""
var stkpkgid3 string = ""
var stkid4 string = ""
var stkpkgid4 string = ""
var myowner string = ""
var myself string = ""
var myclient string = ""
var mytoken string = ""
var zV1 string = ""
var zV2 string = ""
var zV3 string = ""
var zV4 string = ""
var zV5 string = ""
var zV6 string = ""
var MessageRespon string = ""
var helpHeader string = ""
var MessageBan string = ""
var MessageWelcome string = ""
var msgbye string = ""
var targetCache string = ""
var singletarget string = ""
var targetCommand string = ""
var limitStatus string = ""
var speedAll string = ""
var connected net.Conn
var Running = map[string]net.Conn{}
var Ajs = map[string]net.Conn{}

type mentions struct {
	MENTIONEES []struct {
		Start string `json:"S"`
		End string `json:"E"`
		Mid string `json:"M"`
	}`json:"MENTIONEES"`
}

type emots struct {
	STICON struct {
		RESOURCES [] struct {
			PRODUCTID string `json:"productId"`
			STICONID string `json:"sticonId"`
		}`json:"resources"`
	}`json:"sticon"`
}

type tagdata struct {
	S string `json:"S"`
	E string `json:"E"`
	M string `json:"M"`
}

type resultConver struct{
	Resultny struct{
		Ipny string`json:"login_ip"`
		Tokeny string`json:"token"`
	}`json:"result"`
}

type resultSimi struct{
	Kata string`json:"result"`
	Status int`json:"status"`
}

type configs struct {
	Rname string `json:"Prefix"`
	Authoken string `json:"Authoken"`
	Status struct{
		Owner string`json:"Owner"`
		Assist []string`json:"AssistToken"`
		Antijs []string`json:"Ajs"`
		Admin []string`json:"Adminlist"`
		Staff []string`json:"Stafflist"`
		Blacklist []string`json:"Blacklist"`
		Fucklist []string`json:"Fucklist"`
		Staylist map[string][]string`json:"Staybot"`
	}`json:"Status"`
	ZxAssist struct{
		zV1 string`json:"ztoken1"`
		zV2 string`json:"ztoken2"`
		zV3 string`json:"ztoken3"`
		zV4 string`json:"ztoken4"`
		zV5 string`json:"ztoken5"`
		zV6 string`json:"ztoken6"`
	}`json:"ZxAssist"`
	Settings struct{
		ProUrl map[string]int `json:"Pro-groupurl"`
		ProInvite map[string]int `json:"Pro-groupinvite"`
		ProName map[string]int `json:"Pro-groupname"`
		DenyTag map[string]int `json:"Pro-groupmention"`
		KickLock map[string]int `json:"Pro-groupmember"`
		JoinLock map[string]int `json:"Pro-groupjoin"`
		AgresifMode int `json:"War-Mode"`
		BlJoin int `json:"Detect-Mode"`
		AutoPurge int `json:"Auto-killban"`
		Stabilizer int `json:"Auto-stabil"`
		Gname map[string]string `json:"Temp-groupname"`
		MessageHeader string `json:"Temp-header"`
		MessageRespon string `json:"Temp-respon-message"`
		MessageUnban string `json:"Temp-unban-message"`
		MessageBye string `json:"Temp-leave-message"`
		MessageWelcome string `json:"Temp-welcome-message"`
		ResponSticker struct{
			Stkid string `json:"stkid"`
			Stkpkgid string `json:"stkpkgid"`
		}`json:"Temp-sticker-respon"`
		ByeSticker struct{
			Stkid string `json:"stkid"`
			Stkpkgid string `json:"stkpkgid"`
		}`json:"Temp-sticker-leave"`
		UnbanSticker struct{
			Stkid string `json:"stkid"`
			Stkpkgid string `json:"stkpkgid"`
		}`json:"Temp-sticker-unban"`
		Forceallstc struct{
			Stkid string `json:"stkid"`
			Stkpkgid string `json:"stkpkgid"`
		}`json:"Temp-sticker-inv"`
	}`json:"Settings"`
}

func deBug(where string, err error) bool {
	if err != nil {
		 fmt.Printf("\033[33m#%s\nReason:\n%s\n\n\033[39m", where, err)
		 return false
	}
	return true
}

func killAssist(){
	for x := range Running{
		val := Running[x]
		val.Close()
    }
}

func killAssist2(target string){
	val := Running[target]
	val.Close()
}

func broadcast(data string){
	for x := range Running{
		val := Running[x]
		val.Write([]byte(data))
    }
}
func broadcast2(target string,data string){
	val := Running[target]
	val.Write([]byte(data))
}

func handleConnection(conn net.Conn) {
	bs := make([]byte, 1024)
	lenk, err := conn.Read(bs)
	if err != nil { fmt.Printf("♪ Connection Error : %s\n", err) }
	recv := string(bs[:lenk])
	if strings.HasPrefix(recv, "asis_"){
		mid := recv[5:]
		Running[mid] = conn
	}else if strings.HasPrefix(recv, "ajs_"){
		mid := recv[4:]
		Ajs[mid] = conn
	}else if strings.HasPrefix(recv, "request_"){
		stringData := recv[8:]
		joinData := strings.Split(stringData, " ")
		if joinData[0] == singletarget{
			if joinData[1] == "limit"{
				timRespon = timRespon + 1
				limitoutTemp = append(limitoutTemp,joinData[0])
				limitStatus += "\n│├• Assist "+ strconv.Itoa(timRespon) +" • ✘"
				targetViewLimit = append(targetViewLimit,joinData[2])
			}else{
				timRespon = timRespon + 1
				limitStatus += "\n│├• Assist "+ strconv.Itoa(timRespon) +" • ✓"
				limitoutTemp = Remove(limitoutTemp,joinData[1])
				targetViewLimit = append(targetViewLimit,joinData[2])
			}
			targetNumber = targetNumber + 1
			if targetNumber <= len(groupLock[targetCache])-1{
				broadcast2(groupLock[targetCache][targetNumber],"ceklimit_"+targetCache)
				singletarget = groupLock[targetCache][targetNumber]
			}
		}
		if len(groupLock[targetCache]) == targetNumber{
			singletarget = ""
			targetNumber = 1
			SendText(targetCache,limitStatus+"\n│╰───•>>>>>\n╰───────────")
			timRespon = 0
			targetViewLimit = []string{}
			limitStatus = "╭───────────\n│╭• Main's stats •"
		}
	}else if strings.HasPrefix(recv, "resultspeed_"){
		stringData := recv[12:]
		timRespon = timRespon + 1
		speedAll += "\n│├• Zx"+ strconv.Itoa(timRespon)+" : "+stringData+"ms"
		if len(myassist) == timRespon{
			SendText(targetCache, speedAll+"\n│╰───•>>>>>\n╰───────────")
			timRespon = 0
			speedAll = ""
		}
	}
}

/* files */
func SaveFile(path string, data []byte) (bool) {
	err := ioutil.WriteFile(path, data, 0644)
	if err!=nil {
		return false
	}
	return true
}
func DeleteFile(path string) (bool) {
	err := os.Remove(path)
	if err!=nil {
		return false
	}
	return true
}
func DownloadObjectMsg(msgid string){
	client := &http.Client{}
	req , err := http.NewRequest("GET","https://obs-sg.line-apps.com/talk/m/download.nhn?oid="+msgid,nil)
	if err != nil {
		fmt.Println(err)
	}
	req.Header.Set("User-Agent", "Line/8.9.0")
	req.Header.Set("X-Line-Application", "IOS\t8.9.0\tiPhone OS\t1")
	req.Header.Set("X-Line-Access", mytoken)
	res, _ := client.Do(req)
	defer res.Body.Close()
	file, err := os.Create("line-result.bin")
	io.Copy(file, res.Body)
	defer file.Close()
}

/* connection */
func ConnectPoll() *core.TalkServiceClient {
	var err error
	var transport thrift.TTransport
	transport, err = thrift.NewTHttpClient("https://ga2s.line.naver.jp/P4")
	deBug("Login Thrift Client Initialize", err)
	var connect *thrift.THttpClient
	connect = transport.(*thrift.THttpClient)
	connect.SetHeader("X-Line-Access", mytoken)
	connect.SetHeader("User-Agent", "LLA/2.17.0 Nexus 5X 10")
	//connect.SetHeader("X-Line-Application", "ANDROIDLITE\t2.17.0\tAndroid OS\t6.0.1")
	connect.SetHeader("X-Line-Application", zxApp)
	connect.SetHeader("x-lal", "en_gb")
	setProtocol := thrift.NewTCompactProtocolFactory()
	protocol := setProtocol.GetProtocol(connect)
	return core.NewTalkServiceClientProtocol(connect, protocol, protocol)
}

func GetlastOp() *core.TalkServiceClient {
	var err error
	var transport thrift.TTransport
	transport, err = thrift.NewTHttpClient("https://gxx.line.naver.jp/S4")
	deBug("Login Thrift Client Initialize", err)
	var connect *thrift.THttpClient
	connect = transport.(*thrift.THttpClient)
	connect.SetHeader("X-Line-Access", mytoken)
	connect.SetHeader("User-Agent", "LLA/2.17.0 Nexus 5X 10")
	//connect.SetHeader("X-Line-Application", "ANDROIDLITE\t2.17.0\tAndroid OS\t6.0.1")
	connect.SetHeader("X-Line-Application", zxApp)
	connect.SetHeader("x-lal", "en_gb")
	setProtocol := thrift.NewTCompactProtocolFactory()
	protocol := setProtocol.GetProtocol(connect)
	return core.NewTalkServiceClientProtocol(connect, protocol, protocol)
}

func ConnectTalk() *core.TalkServiceClient {
	var err error
	var transport thrift.TTransport
	transport, err = thrift.NewTHttpClient("https://gxx.line.naver.jp/S4")
	deBug("Login Thrift Client Initialize", err)
	var connect *thrift.THttpClient
	connect = transport.(*thrift.THttpClient)
	connect.SetHeader("X-Line-Access", mytoken)
	connect.SetHeader("User-Agent", "LLA/2.17.0 Nexus 5X 10")
	//connect.SetHeader("X-Line-Application", "ANDROIDLITE\t2.17.0\tAndroid OS\t6.0.1")
	connect.SetHeader("X-Line-Application", zxApp)
	setProtocol := thrift.NewTCompactProtocolFactory()
	protocol := setProtocol.GetProtocol(connect)
	return core.NewTalkServiceClientProtocol(connect, protocol, protocol)
}

func getLastOpRevision()int64{
	client := GetlastOp()
	r, e := client.GetLastOpRevision(context.TODO())
	deBug("getLastOpRevision", e)
	return r
}

func GetServerTime()int64{
	client := ConnectTalk()
	r, e := client.GetServerTime(context.TODO())
	deBug("GetServerTime", e)
	return r
}

func fetchOperations(last int64,count int32) (r []*core.Operation){
	client := ConnectPoll()
	r, e:= client.FetchOperations(context.TODO(),last,count)
	deBug("fetchOperations", e)
	return r
}

func multiOperations(last int64,count int32,global int64,individu int64)(r []*core.Operation){
	client := ConnectPoll()
	r, e := client.FetchOps(context.TODO(),last,count,global,individu)
	deBug("multiOperations", e)
	return r
}

func GetIdForImage(toID string)(r *core.Message){
	client := ConnectTalk()
	msgObj := core.NewMessage()
	msgObj.ContentType = core.ContentType_IMAGE
	msgObj.To = toID
	r , e := client.SendMessage(context.TODO(), Seq, msgObj)
	deBug("GetIdForImage", e)
	return r
}

func SendText(toID string,msgText string){
	client := ConnectTalk()
	msgObj := core.NewMessage()
	msgObj.ContentType = core.ContentType_NONE
	msgObj.To = toID
	msgObj.Text = msgText
	_, e := client.SendMessage(context.TODO(), Seq, msgObj)
	deBug("SendText", e)
}

func SendContact(toID string, mid string) {
	client := ConnectTalk()
	msgObj := core.NewMessage()
	msgObj.ContentType = core.ContentType_CONTACT
	msgObj.To = toID
	msgObj.Text = ""
	msgObj.ContentMetadata = map[string]string{"mid":mid}
	_, e := client.SendMessage(context.TODO(), Seq, msgObj)
	deBug("SendContact", e)
}

func SendTextMention(toID string,msgText string,mids []string) {
	client := ConnectTalk()
	arr := []*tagdata{}
	mentionee := "@unix"
	texts := strings.Split(msgText, "@!")
	textx := ""
	for i := 0; i < len(mids); i++ {
		textx += texts[i]
        arr = append(arr, &tagdata{S: strconv.Itoa(len(textx)), E: strconv.Itoa(len(textx) + 5), M:mids[i]})
        textx += mentionee
	}
	textx += texts[len(texts)-1]
	allData,_ := json.MarshalIndent(arr, "", " ")
	msgObj := core.NewMessage()
	msgObj.ContentType = core.ContentType_NONE
	msgObj.To = toID
	msgObj.Text = textx
	msgObj.ContentMetadata = map[string]string{"MENTION": "{\"MENTIONEES\":"+string(allData)+"}"}
	_, e := client.SendMessage(context.TODO(), Seq, msgObj)
	deBug("SendTextMention", e)
}

func SendTextMentionByList(to string,msgText string,targets []string){
	listMid := targets
	listMid2 := []string{}
	listChar := msgText
	listNum := 0
	loopny := len(listMid) / 20 + 1
	limiter := 0
	limiter2 := 20
	for a:=0;a<loopny;a++{
		for c:=limiter;c<len(listMid);c++{
			if c < limiter2{
				listNum = int(listNum) + 1
				listMid2 = append(listMid2,listMid[c])
				limiter = limiter + 1
			}else{
				limiter2 = limiter + 20
				break
			}
		}
		SendTextMention(to,listChar,listMid2)
		listChar = ""
		listMid2 = []string{}
	}
}

// **send message multi mentions** //
func SendTextMentionByList2(to string,msgText string,targets []string){
	listMid := targets
	listMid2 := []string{}
	listChar := msgText
	listNum := 0
	loopny := len(listMid) / 20 + 1
	limiter := 0
	limiter2 := 20
	for a:=0;a<loopny;a++{
		for c:=limiter;c<len(listMid);c++{
			if c < limiter2{
				listNum = int(listNum) + 1
				listChar += "\n" + strconv.Itoa(listNum) + ". @!\n"
				listMid2 = append(listMid2,listMid[c])
				limiter = limiter + 1
			}else{
				limiter2 = limiter + 20
				break
			}
		}
		SendTextMention(to,listChar,listMid2)
		listChar = ""
		listMid2 = []string{}
	}
}

func startAssist(){
	err := exec.Command("bash", "-c", "cd zxLib&&./asv1 "+argsRaw[1]+" "+zV1+" "+port).Start()
	exec.Command("bash", "-c", "cd zxLib&&./asv2 "+argsRaw[1]+" "+zV2+" "+port).Start()
	exec.Command("bash", "-c", "cd zxLib&&./asv3 "+argsRaw[1]+" "+zV3+" "+port).Start()
	exec.Command("bash", "-c", "cd zxLib&&./asv4 "+argsRaw[1]+" "+zV4+" "+port).Start()
	exec.Command("bash", "-c", "cd zxLib&&./asv5 "+argsRaw[1]+" "+zV5+" "+port).Start()
	exec.Command("bash", "-c", "cd zxLib&&./asv6 "+argsRaw[1]+" "+zV6+" "+port).Start()
	if err != nil { fmt.Println(err) }
	startingBots()
}

func DeleteOtherFromChat(groupId string, contactIds []string){
	client := ConnectTalk()
	fst := core.NewDeleteOtherFromChatRequest()
	fst.ReqSeq = Seq
	fst.ChatMid = groupId
	fst.TargetUserMids = contactIds
	_, e := client.DeleteOtherFromChat(context.TODO(), fst)
	deBug("DeleteOtherFromChat", e)
}
func InviteIntoChat(groupId string, contactIds []string){
	client := ConnectTalk()
	fst := core.NewInviteIntoChatRequest()
	fst.ReqSeq = Seq
	fst.ChatMid = groupId
	fst.TargetUserMids = contactIds
	_, e := client.InviteIntoChat(context.TODO(), fst)
	deBug("InviteIntoChat", e)
}
func CancelChatInvitation(groupId string, contactIds []string){
	client := ConnectTalk()
	fst := core.NewCancelChatInvitationRequest()
	fst.ReqSeq = Seq
	fst.ChatMid = groupId
	fst.TargetUserMids = contactIds
	_, err := client.CancelChatInvitation(context.TODO(), fst)
	deBug("CancelChatInvitation", err)
}
func AcceptChatInvitation(groupId string){
	client := ConnectTalk()
	v := core.NewAcceptChatInvitationRequest()
	v.ReqSeq = Seq
	v.ChatMid = groupId
	_, e := client.AcceptChatInvitation(context.TODO(), v)
	deBug("AcceptChatInvitation", e)
}
func GetChat(targets []string, opsiMembers bool, opsiPendings bool)(r *core.GetChatsResponse){
	client := ConnectTalk()
	v := core.NewGetChatsRequest()
	v.ChatMids = targets
	v.WithMembers = opsiMembers
	v.WithInvitees = opsiPendings
	r, e := client.GetChats(context.TODO(), v)
	deBug("GetChat", e)
	return r
}
func UpdateQrChat(groupOBJ *core.Chat){
	client := ConnectTalk()
	v := core.NewUpdateChatRequest()
	v.ReqSeq = Seq
	v.Chat = groupOBJ
	v.UpdatedAttribute = core.ChatAttribute_PREVENTED_JOIN_BY_TICKET
	_, e := client.UpdateChat(context.TODO(), v)
	deBug("UpdateChatQr", e)
}
func UpdateNameChat(groupOBJ *core.Chat){
	client := ConnectTalk()
	v := core.NewUpdateChatRequest()
	v.ReqSeq = Seq
	v.Chat = groupOBJ
	v.UpdatedAttribute = core.ChatAttribute_NAME
	_, e := client.UpdateChat(context.TODO(), v)
	deBug("UpdateChatName", e)
}
func AcceptChatInvitationByTicket(groupId string, ticketId string){
	client := ConnectTalk()
	v := core.NewAcceptChatInvitationByTicketRequest()
	v.ReqSeq = Seq
	v.ChatMid = groupId
	v.TicketId = ticketId
	_, e := client.AcceptChatInvitationByTicket(context.TODO(), v)
	deBug("AcceptChatInvitationByTicket", e)
}
func FindChatByTicket(ticketId string)(r *core.FindChatByTicketResponse){
	client := ConnectTalk()
	v := core.NewFindChatByTicketRequest()
	v.TicketId = ticketId
	r, e := client.FindChatByTicket(context.TODO(), v)
	deBug("FindChatByTicket", e)
	return r
}
func GetChatTicket(groupId string)(r *core.ReissueChatTicketResponse){
	client := ConnectTalk()
	v := core.NewReissueChatTicketRequest()
	v.ReqSeq = Seq
	v.GroupMid = groupId
	r, err := client.ReissueChatTicket(context.TODO(), v)
	deBug("GetChatTicket", err)
	return r
}

// talk v1  //
func KickoutFromGroup(groupId string, contactIds []string) {
	client := ConnectTalk()
	e := client.KickoutFromGroup(context.TODO(), Seq, groupId, contactIds)
	deBug("KickoutFromGroup", e)
}
func InviteIntoGroup(groupId string, contactIds []string) {
	client := ConnectTalk()
	e := client.InviteIntoGroup(context.TODO(), Seq, groupId, contactIds)
	deBug("InviteIntoGroup", e)
}
func CancelInvite(groupId string, contactIds []string) {
	client := ConnectTalk()
	e := client.CancelGroupInvitation(context.TODO(), Seq, groupId, contactIds)
	deBug("CancelInvite", e)
}
func AcceptGroup(groupId string) {
	client := ConnectTalk()
	e := client.AcceptGroupInvitation(context.TODO(), Seq, groupId)
	deBug("AcceptGroup", e)
}
func UpdateGroup(groupOBJ *core.Group) {
	client := ConnectTalk()
	e := client.UpdateGroup(context.TODO(), Seq, groupOBJ)
	deBug("UpdateGroup", e)
}
func GetGroup(groupId string)(r *core.Group){
	client := ConnectTalk()
	r, e := client.GetGroup(context.TODO(), groupId)
	deBug("GetGroup", e)
	return r
}
func GetContact(id string) (r *core.Contact){
	client := ConnectTalk()
	r, e := client.GetContact(context.TODO(), id)
	deBug("GetContact", e)
	return r
}
func RemoveContact(id string){
	client := ConnectTalk()
	e := client.UpdateContactSetting(context.TODO(), Seq, id, 16, "true")
	deBug("RemoveContact", e)
}
func GetProfile()*core.Profile{
	client := ConnectTalk()
	r, e := client.GetProfile(context.TODO())
	deBug("GetProfile", e)
	return r
}
func LeaveGroup(groupId string){
	client := ConnectTalk()
	e := client.LeaveGroup(context.TODO(), Seq, groupId)
	deBug("LeaveGroup", e)
}
func AcceptGroupByTicket(groupMid string, ticketId string){
	client := ConnectTalk()
	e := client.AcceptGroupInvitationByTicket(context.TODO(), Seq, groupMid, ticketId)
	deBug("AcceptGroupByTicket", e)
}
func FindGroupByTicket(ticketId string)(r *core.Group){
	client := ConnectTalk()
	r, e := client.FindGroupByTicket(context.TODO(), ticketId)
	deBug("FindGroupByTicket", e)
	return r
}
func GetGroupTicket(groupMid string)(r string){
	client := ConnectTalk()
	r, e := client.ReissueGroupTicket(context.TODO(), groupMid)
	deBug("GetGroupTicket", e)
	return r
}
func UnsendMessage(messageId string){
	client := ConnectTalk()
	e := client.UnsendMessage(context.TODO(), Seq, messageId)
	deBug("UnsendMessage", e)
}

// ........................................... //
func bToMb(b uint64) uint64 {
    return b / 1024 / 1024
}

func autoUnlock(){
	for{
			<-time.After(6 * time.Second)
			antipurge = 1
	}
}

func speedStabilizer(){
	for{
		if stabilizer == 1{
			<-time.After(380 * time.Second)
			fth := GetProfile()
			fth.DisplayName = fth.DisplayName
			UpdateProfile(fth)
		}
	}
}

func cekSquad(to string){
	gc := GetGroup(to)
	temprs := []string{}
	jumSquad := []string{}
	r := ""
	_, found := groupLock[to]
	if found == false{
		fmt.Println("♪ Invite fails, I'am limit\n  Warmode is turned off")
	}else{
		if len(groupLock[to]) > 0{
			for i:= range groupLock[to]{
				temprs = append(temprs,groupLock[to][i])
				r += "\n"+"  @!"
			}
			for i:= range gc.Members{
				for i2:= range myteam{
					if gc.Members[i].Mid == myteam[i2]{
						jumSquad = append(jumSquad, gc.Members[i].Mid)
					}
				}
			}
			if len(jumSquad) <= len(myassist){
				saveJson()
				broadcast("loadjson")
				SendTextMentionByList(to, "Invitation success"+r+"\n"+strconv.Itoa(len(jumSquad))+"/"+strconv.Itoa(len(myteam))+" assist in here.",temprs)
			}else{SendText(to, "✘ Invite fails, I'am limit\n  Warmode is turned off")}
			saveJson()
			broadcast("loadjson")
		}
	}
}

func CheckExpired(){
	loc, _ := time.LoadLocation("Asia/Jakarta")
	batas := time.Date(2021, 1, 30, 0, 0, 0, 0, loc)
	timeup := 365 //day(hari)
	timePassed := time.Since(batas)
	expired := timePassed.Hours() / 24
	cnvrt := fmt.Sprintf("%.1f", expired)
	splitter := strings.Split(cnvrt,".")
	duedate, _ := strconv.Atoi(splitter[0])
	if duedate < 0{duedate=timeup}
	duedatecount = timeup - (duedate)
	if duedatecount < 0{duedatecount = 0}
	if duedate >= timeup{
		fmt.Println("\033[33m\nYour Golang App is expired !\n\nPlease Contact LineID : shadow.bots\n\n\033[39m")
		os.Exit(1)
	}
}

func GenerateTimeLog(to string){
	loc, _ := time.LoadLocation("Asia/Makassar")
	a:=time.Now().In(loc)
	yyyy := strconv.Itoa(a.Year())
	MM := a.Month().String()
	dd := strconv.Itoa(a.Day())
	hh := a.Hour()
	mm := a.Minute()
	ss := a.Second()
	var hhconv string
	var mmconv string
	var ssconv string
	if hh < 10 {
		hhconv = "0"+strconv.Itoa(hh)
	}else {
		hhconv = strconv.Itoa(hh)
	}
	if mm < 10 {
		mmconv = "0"+strconv.Itoa(mm)
	}else {
		mmconv = strconv.Itoa(mm)
	}
	if ss < 10 {
		ssconv = "0"+strconv.Itoa(ss)
	}else {
		ssconv = strconv.Itoa(ss)
	}
	times := "Date : "+dd+"/"+MM+"/"+yyyy+"\nTime : "+hhconv+":"+mmconv+":"+ssconv
	SendText(to,times)
}

func GetRecentMessages(messageBoxId string)(r []*core.Message){
	client := ConnectTalk()
	r, err := client.GetRecentMessages(context.TODO(),messageBoxId,1000)
	deBug("GetRecentMessages", err)
	return r
}

func GetAccountSettings()(r *core.Settings){
	client := ConnectTalk()
	r, err := client.GetSettings(context.TODO())
	deBug("GetAccountSettings", err)
	return r
}

func GetCompactGroup(groupId string) (r *core.Group) {
	client := ConnectTalk()
	r, err := client.GetCompactGroup(context.TODO(), groupId)
	deBug("GetCompactGroup", err)
	return r
}

func GetGroupWithoutMembers(groupId string)(r *core.Group){
	client := ConnectTalk()
	r, err := client.GetGroupWithoutMembers(context.TODO(), groupId)
	deBug("GetGroupWithoutMembers", err)
	return r
}

func GetAllFriends() (r []string) {
	client := ConnectTalk()
	r, err := client.GetAllContactIds(context.TODO())
	deBug("GetAllFriends", err)
	return r
}

func loadJson(){
	jsonName = fmt.Sprintf("zxJson/%s.json", argsRaw[1])
	jsonFile, err := os.Open(jsonName)
	if err != nil{
		deBug("Load JSON File: ", err)
		os.Exit(1)
	}
	defer jsonFile.Close()
	srcJSON, _ := ioutil.ReadAll(jsonFile)
	err = json.Unmarshal([]byte(srcJSON), &Configs)
	deBug("JSON Initialize: ", err)
	rname = Configs.Rname
	proQr = Configs.Settings.ProUrl
	proInvite = Configs.Settings.ProInvite
	agresifMode = Configs.Settings.AgresifMode
	detectBL = Configs.Settings.BlJoin
	proName = Configs.Settings.ProName
	autoPurge = Configs.Settings.AutoPurge
	saveGname = Configs.Settings.Gname
	denyTag = Configs.Settings.DenyTag
	kickLock = Configs.Settings.KickLock
	joinLock = Configs.Settings.JoinLock
	bans = Configs.Status.Blacklist
	zbans = Configs.Status.Fucklist
	myadmin = Configs.Status.Admin
	mystaff = Configs.Status.Staff
	stabilizer = Configs.Settings.Stabilizer
	stkid = Configs.Settings.ResponSticker.Stkid
	stkpkgid = Configs.Settings.ResponSticker.Stkpkgid
	stkid3 = Configs.Settings.ByeSticker.Stkid
	stkpkgid3 = Configs.Settings.ByeSticker.Stkpkgid
	stkid4 = Configs.Settings.UnbanSticker.Stkid
	stkpkgid4 = Configs.Settings.UnbanSticker.Stkpkgid
	MessageRespon = Configs.Settings.MessageRespon
	helpHeader = Configs.Settings.MessageHeader
	MessageBan = Configs.Settings.MessageUnban
	msgbye = Configs.Settings.MessageBye
	myowner = Configs.Status.Owner
	mytoken = Configs.Authoken
	myassist = Configs.Status.Assist
	myantijs = Configs.Status.Antijs
	groupLock = Configs.Status.Staylist
	myclient = Configs.Authoken[:33]
	MessageWelcome = Configs.Settings.MessageWelcome
}

func GetGroupsInvited()(r []string) {
	client := ConnectTalk()
	r, err := client.GetGroupIdsInvited(context.TODO())
	deBug("GetGroupsInvited", err)
	return r
}

func GetGroupsJoined()(r []string) {
	client := ConnectTalk()
	r, err := client.GetGroupIdsJoined(context.TODO())
	deBug("GetGroupsJoined", err)
	return r
}

func CreateGroup(name string, contactIds []string) (r *core.Group) {
	client := ConnectTalk()
	r, err := client.CreateGroup(context.TODO(), Seq, name, contactIds)
	deBug("CreateGroup", err)
	return r
}

func RemoveAllMessage(lastMessageId string){
	client := ConnectTalk()
	err := client.RemoveAllMessages(context.TODO(), Seq, lastMessageId)
	deBug("RemoveAllMessage", err)
}

func AddContactByMid(mid string) (r map[string]*core.Contact) {
	client := ConnectTalk()
	r, err := client.FindAndAddContactsByMid(context.TODO(), Seq, mid)
	deBug("AddContactByMid", err)
	return r
}

func UpdateProfile(profile *core.Profile){
	client := ConnectTalk()
	err := client.UpdateProfile(context.TODO(), Seq, profile)
	deBug("UpdateProfile", err)
}

func startingBots(){
	getReady := GetGroupsJoined()
	cloudtim := []string{}
	cloudget := []string{}
	for cu := range myassist{
		cloudtim = append(cloudtim,myassist[cu][:33])
		myteam = append(myteam,myassist[cu][:33])
	}
	for in := range getReady{
		gtarget := getReady[in]
		checkin := GetGroup(gtarget).Members
		for ui := range checkin{
			cloudget = append(cloudget,checkin[ui].Mid)
		}
		_, found := groupLock[gtarget]
		if found == false{
		for ix := range checkin{
			if contains(cloudtim,checkin[ix].Mid){
				if uncontains(groupLock[gtarget],checkin[ix].Mid){
					groupLock[gtarget] = append(groupLock[gtarget],checkin[ix].Mid)
				}
			}
		}
	}else{
		if len(groupLock[gtarget]) == 0{
			delete(groupLock,gtarget)
		}else{
			for ixx := range groupLock[gtarget]{
				if uncontains(cloudget,groupLock[gtarget][ixx]){
					groupLock[gtarget] = Remove(groupLock[gtarget],groupLock[gtarget][ixx])
				}
			}
		}
		cloudget = []string{}
	}
	}
	saveJson()
	for i := range myassist{
		target := string(myassist[i][:33])
		fmt.Println(target)
		if target != myself{
			if nothingInMyContacts(target){
				time.Sleep(1 * time.Second)
				fmt.Println(target)
				AddContactByMid(target)
			}
		}
	}
}

func addAsFriendContact(target string){
	if nothingInMyContacts(target){
		AddContactByMid(target)
	}
}

func botDuration(d time.Duration) string {
	d = d.Round(time.Second)
	h := d / time.Hour
	d -= h * time.Hour
	m := d / time.Minute
	d -= m * time.Minute
	s := d / time.Second
	return fmt.Sprintf("%02dʰᵒᵘʳ:%02dᵐⁱⁿ:%02dˢᵉᶜ", h%24, m, s)
}

func botDuration2(d time.Duration) string {
	d = d.Round(time.Second)
	h := d / time.Hour
	d -= h * time.Hour
	m := d / time.Minute
	d -= m * time.Minute
	s := d / time.Second
	return fmt.Sprintf("%02dᵈᵃʸˢ:%02dʰᵒᵘʳ:%02dᵐⁱⁿ:%02dˢᵉᶜ", h/24, h%24, m, s)
}

func MyContactTicket() (r *core.Ticket) {
	client := ConnectTalk()
	r, err := client.GetUserTicket(context.TODO())
	deBug("MyContactTicket", err)
	return r
}

func Remove(s []string, r string) []string {
	new := make([]string, len(s))
	copy(new, s)
	for i, v := range new {
		if v == r {
			return append(new[:i], new[i+1:]...)
		}
	}
	return s
}

func CheckEmots(data *core.Operation){
	sender := data.Message.From_
	to := data.Message.To
	emots := emots{}
	json.Unmarshal([]byte(data.Message.ContentMetadata["REPLACE"]), &emots)
	for _, stiker := range emots.STICON.RESOURCES{
		if myowner == sender||contains(myadmin,sender)||contains(mycreator,sender){
			if getStickerRespon == 1{
				if myowner == string(sender){
					stkid = stiker.PRODUCTID
					stkpkgid = stiker.STICONID
					saveJson()
					getStickerRespon = 0
					SendText(to, "♪ Respon by sticker updated")
				}
			}else if getStickerKick == 1{
				 if myowner == string(sender) || contains(mycreator,sender){
						stkid2 = stiker.PRODUCTID
						stkpkgid2 = stiker.STICONID
						saveJson()
						getStickerKick = 0
						SendText(to, "♪ Kick by sticker updated")
				 }
			}else if getStickerBye == 1{
				 if myowner == string(sender){
						stkid3 = stiker.PRODUCTID
						stkpkgid3 = stiker.STICONID
						getStickerBye = 0
						SendText(to, "♪ Bye by sticker updated")
				 }
			}else if getStickerUnban == 1{
				 if myowner == string(sender){
						stkid4 = stiker.PRODUCTID
						stkpkgid4 = stiker.STICONID
						getStickerUnban = 0
						SendText(to, "♪ Unban by sticker updated")
				 }
			}else if stiker.PRODUCTID == stkid && stiker.STICONID == stkpkgid{
				_, found := groupLock[to]
				if found == false{SendText(to, MessageRespon)
				}else{
					if len(groupLock[to]) > 0{
						SendText(to, MessageRespon)
						targetNumber = 0
						targetCommand = "ready"
						singletarget = string(groupLock[to][0])
						broadcast2(groupLock[to][0],"respon_"+to)
					}else{SendText(to, MessageRespon)}
				}
			}else if stiker.PRODUCTID == stkid2 && stiker.STICONID == stkpkgid2{
				_, found := data.Message.ContentMetadata["message_relation_server_message_id"]
				if found == true{
					for i := range msgTemp{
						if contains(msgTemp[i],data.Message.ContentMetadata["message_relation_server_message_id"]){
							if !fullAccess(i){
								DeleteOtherFromChat(to,[]string{i})
								break
							}
						}
					}
				}
			}else if stiker.PRODUCTID == stkid3 && stiker.STICONID == stkpkgid3{
				delete(readerTemp,to)
				delete(checkRead,to)
				delete(proInvite,to)
				delete(proName,to)
				delete(proQr,to)
				delete(joinLock,to)
				delete(denyTag,to)
				delete(kickLock,to)
				delete(saveGname,to)
				delete(groupLock,to)
				saveJson()
				SendText(to, msgbye)
				LeaveGroup(to)
			}else if stiker.PRODUCTID == stkid4 && stiker.STICONID == stkpkgid4{
				if len(bans) == 0{
					SendText(to, "♪ No have blacklist.")
				}else{
					msgchn:= fmt.Sprintf(MessageBan,len(bans))
					SendText(to, msgchn)
					bans = []string{}
					saveJson()
				}
			}
		}
		break
	}
}

func cekTypeToken(){
	r := len([]rune(mytoken))
	if r != 184{
		if r == 92{//prymary
			fmt.Println("\033[33mPrymary authoken is not permitted to login\033[39m")
			os.Exit(1)
		}else if r == 54{//secondary
			fmt.Println("\033[33mSecondary authoken is not permitted to login\033[39m")
			os.Exit(1)
		}else{//ngasal
			fmt.Println("\033[33minvalid authoken\033[39m")
			os.Exit(1)
		}
	}
}

func nodejs(gid string,authjs string,cms string){
	cmo:=fmt.Sprintf("node zxLib/kick.js gid=%s %s token=%s",gid,cms,authjs)
	parts := strings.Fields(cmo)
	cmd, _ := exec.Command(parts[0],parts[1:]...).Output()
	fmt.Println(string(cmd))
}
func nodejs2(gid string,authjs string,cms1 string,cms2 string){
	cmo:=fmt.Sprintf("node zxLib/double.js gid=%s %s %s token=%s",gid,cms1,cms2,mytoken)
	parts := strings.Fields(cmo)
	cmd, _ := exec.Command(parts[0],parts[1:]...).Output()
	fmt.Println(string(cmd))
}
func nodejs3(gid string,authjs string,cms string){
	cmo:=fmt.Sprintf("node zxLib/cancel.js gid=%s %s token=%s",gid,cms,mytoken)
	parts := strings.Fields(cmo)
	cmd, _ := exec.Command(parts[0],parts[1:]...).Output()
	fmt.Println(string(cmd))
}

func nothingInMyContacts(target string) bool {
	friends := GetAllFriends()
	if uncontains(friends,target){
		return true
	}
	return false
}

func contains(arr []string, str string) bool{
	for i:=0;i<len(arr);i++{
		if arr[i] == str{
			return true
		}
	}
	return false
}

func uncontains(arr []string, str string) bool{
	for i:=0;i<len(arr);i++{
		if arr[i] == str{
			return false
		}
	}
	return true
}

func checkip(ip string) bool {
	conn, err := net.Dial("udp", "8.8.8.8:80")
  conn.Close()
  localAddr := conn.LocalAddr().(*net.UDPAddr)
	localip := strings.Split((localAddr).String(),":")
	myip = localip[0]
	if err != nil{
		 os.Exit(1)
	}else if string(localip[0]) != ip{
        fmt.Println("\033[33m\nYour ip [\033[39m"+ localip[0] +"\033[33m] is not registered !\n\nPlease Contact LineID : @956wmiaj\n\n\033[39m")
		    os.Exit(1)
  }else if string(localip[0]) == ip{
		return true
  }
	return false
}

func saveJson(){
	Configs.Rname = rname
	Configs.Settings.ProUrl = proQr
	Configs.Settings.AgresifMode = agresifMode
	Configs.Settings.BlJoin = detectBL
	Configs.Settings.ProInvite = proInvite
	Configs.Settings.ProName = proName
	Configs.Settings.AutoPurge = autoPurge
	Configs.Settings.Gname = saveGname
	Configs.Status.Blacklist = bans
	Configs.Status.Fucklist = zbans
	Configs.Status.Admin = myadmin
	Configs.Status.Staff = mystaff
	Configs.Settings.ResponSticker.Stkid = stkid
	Configs.Settings.ResponSticker.Stkpkgid = stkpkgid
	Configs.Settings.MessageRespon = MessageRespon
	Configs.Status.Owner = myowner
	Configs.Authoken = mytoken
	Configs.ZxAssist.zV1 = zV1
	Configs.ZxAssist.zV2 = zV2
	Configs.ZxAssist.zV3 = zV3
	Configs.ZxAssist.zV4 = zV4
	Configs.ZxAssist.zV5 = zV5
	Configs.ZxAssist.zV6 = zV6
  Configs.Settings.DenyTag = denyTag
  Configs.Settings.KickLock = kickLock
	Configs.Settings.JoinLock = joinLock
	Configs.Settings.MessageHeader = helpHeader
	Configs.Settings.MessageUnban = MessageBan
	Configs.Settings.MessageBye = msgbye
	Configs.Settings.MessageWelcome = MessageWelcome
	Configs.Settings.ByeSticker.Stkid = stkid3
	Configs.Settings.ByeSticker.Stkpkgid = stkpkgid3
	Configs.Settings.UnbanSticker.Stkid = stkid4
	Configs.Settings.UnbanSticker.Stkpkgid = stkpkgid4
	Configs.Settings.Stabilizer = stabilizer
	Configs.Status.Assist = myassist
	Configs.Status.Antijs = myantijs
	Configs.Status.Staylist = groupLock
	encjson, _ := json.MarshalIndent(Configs, "", "  ")
	ioutil.WriteFile(jsonName, encjson, 0644)
}

func GetSimiliarName(loc string,target string){
	ts := GetContact(target)
	myString := ts.DisplayName
	a := []rune(myString)
	myShortString := string(a[0:3])
	gc := GetGroup(loc)
	targets := gc.Members
	for i:= range targets{
		cach := []rune(targets[i].DisplayName)
		if string(cach[0:3]) == myShortString{
			if !fullAccess(targets[i].Mid){
				if myself != targets[i].Mid{
					appendBl(targets[i].Mid)
				}
			}
		}
	}
	antipurge = 0
}

func MaxRevision(a, b int64)int64 {
	if a > b {
		return a
	}
	return b
}

func karungin(trgt string){
	if uncontains(zbans, trgt){
	   zbans = append(zbans, trgt)
	 }
}

func keluarin(trgt string){
	for i:=0;i<len(zbans);i++{
		if zbans[i] == trgt{
			zbans = Remove(zbans,zbans[i])
		}
	}
}

func appendBl(target string){
	if uncontains(bans, target){
	   bans = append(bans, target)
	 }
}

func removeBl(target string){
	for i:=0;i<len(bans);i++{
		if bans[i] == target{
			bans = Remove(bans,bans[i])
		}
	}
}

func poolKickBanWhenAccept(lc string){
	time.Sleep(1000 * time.Microsecond)
  var wg sync.WaitGroup
  wg.Add(len(bans))
	for i:=0;i<len(bans);i++ {
		go func(i int) {
			defer wg.Done()
			DeleteOtherFromChat(lc,[]string{bans[i]})
    }(i)
	}
	wg.Wait()
}

func poolKickBans(lc string){
  var wg sync.WaitGroup
  wg.Add(len(bans))
	for i:=0;i<len(bans);i++ {
		go func(i int) {
			defer wg.Done()
			DeleteOtherFromChat(lc,[]string{bans[i]})
    }(i)
	}
	wg.Wait()
}

func checkEqual(list1 []string, list2 []string) bool {
	  looper1 := len(list1)
		looper2 := len(list2)
		for i1:=0;i1<looper1;i1++{
			for i2:=0;i2<looper2;i2++{
				if list1[i1] == list2[i2]{
					 return true
				}
			}
		}
		return false
}

// **cek target all access** //
func fullAccess(target string) bool{
	data := []string{myowner}
	data = append(data,myteam...)
	data = append(data,mycreator...)
	data = append(data,myadmin...)
	data = append(data,mystaff...)
	looper := len(data)
	for i:=0;i<looper;i++{
		if target == data[i]{
			 return true
		}
	}
	return false
}

// **cek target some access** //
func access(target string) bool{
	data := []string{myowner}
	data = append(data,mycreator...)
	data = append(data,myadmin...)
	data = append(data,mystaff...)
	looper := len(data)
	for i:=0;i<looper;i++{
		if target == data[i]{
			 return true
		}
	}
	return false
}

func Parallelize(functions ...func()) {
	rng := len(functions)
	var wg sync.WaitGroup
	wg.Add(rng)
	for i:=0;i<rng;i++ {
		go func(copy func()){
			defer wg.Done()
			copy()
		}(functions[i])
	}
	wg.Wait()
}

func poolCancel(lc string,pd []string){
  var wg sync.WaitGroup
  wg.Add(len(pd))
	for i:=0;i<len(pd);i++ {
		go func(i int) {
			defer wg.Done()
			CancelChatInvitation(lc,[]string{pd[i]})
    }(i)
	}
	wg.Wait()
}

func cleardns() {
	cmd, _ := exec.Command("bash","-c","sudo systemd-resolve --flush-caches").Output()
	fmt.Println("\033[33m"+string(cmd)+"\033[39m")
}
func installer() {
	cmd, _ := exec.Command("bash","-c","sudo systemd-resolve --flush-caches").Output()
	exec.Command("bash","-c","pip3 uninstall thrift&&y").Output()
	fmt.Println("\033[33m"+string(cmd)+"\033[39m")
}

func callProfile(cmd1 string, cmd2 string) {
	cmd, _ := exec.Command("python3","zxLib/lineProfile.py",mytoken,myself,cmd1,cmd2).Output()
	fmt.Println("\033[33m"+string(cmd)+"\033[39m")
}

func sendBigImage(grp string, imglink string) {
	cmd, _ := exec.Command("python3","zxLib/liff.py",mytoken,grp,imglink).Output()
	fmt.Println("\033[33m"+string(cmd)+"\033[39m")
}
//clear
func scanNameTarget(lc string,pl string){
	runtime.GOMAXPROCS(cpu)
	go func(){if antipurge == 1{GetSimiliarName(lc,pl)}}()
	go func(){appendBl(pl)}()
}
//clear
func proQrGroup(lc string,pl string,kr string){
	runtime.GOMAXPROCS(cpu)
	if kr == "4"{
		go func(){g := GetGroupWithoutMembers(lc);if g.PreventedJoinByTicket == false{g.PreventedJoinByTicket = true;UpdateGroup(g)}}()
		go func(){appendBl(pl)}()
	}
}

func closeQr(lc string){
	runtime.GOMAXPROCS(cpu)
	go func(){g := GetGroupWithoutMembers(lc);if g.PreventedJoinByTicket == false{g.PreventedJoinByTicket = true;UpdateGroup(g)}}()
}

func proNameGroup(lc string,pl string){
	runtime.GOMAXPROCS(cpu)
	go func(){g := GetGroupWithoutMembers(lc);if g.Name != saveGname[lc]{g.Name = saveGname[lc];UpdateGroup(g)}}()
	go func(){appendBl(pl)}()
}

func command(op *core.Operation) {
	if op.Type == 19||op.Type == 133{
		location := op.Param1
		enemy := op.Param2
		victim := op.Param3
		if contains(myteam,victim) && !fullAccess(enemy){
			appendBl(enemy)
		}else if victim == myself && !fullAccess(enemy){
			scanNameTarget(location,enemy)
		}else if contains(myteam,enemy) && !fullAccess(victim){
			appendBl(victim)
		}else if access(victim) && !fullAccess(enemy){
			appendBl(enemy)
		}
	}else if op.Type == 13||op.Type == 124{
		location := op.Param1
		enemy := op.Param2
		victim := strings.Split(op.Param3,"\x1e")
		if contains(myteam,enemy) && contains(victim,myself){
			AcceptChatInvitation(location)
		}else if checkEqual(victim,bans){
			runtime.GOMAXPROCS(cpu)
			go func(){
				for i:=range victim{appendBl(victim[i])}
				if !fullAccess(enemy){appendBl(enemy)}
			}()
	  }else if contains(bans,enemy){
			runtime.GOMAXPROCS(cpu)
			go func(){
				for i:=range victim{appendBl(victim[i])}
				if !fullAccess(enemy){appendBl(enemy)}
			}()
		}else if proInvite[location] == 1 && !fullAccess(enemy){
			runtime.GOMAXPROCS(cpu)
			go func(){
				for i:=range victim{appendBl(victim[i])}
				if !fullAccess(enemy){appendBl(enemy)}
			}()
		}else if access(enemy) && contains(victim,myself){
			AcceptChatInvitation(location)
			if agresifMode == 1{
				troops := []string{}
				for i:= range myassist{
					troops = append(troops,myassist[i][:33])
					if uncontains(groupLock[location],myassist[i][:33]){
						groupLock[location] = append(groupLock[location],myassist[i][:33])
					}
				}
				InviteIntoChat(location,troops)
				time.Sleep(1 * time.Second)
				cekSquad(location)
			}
			saveJson()
			broadcast("loadjson")
		}
	}else if op.Type == 17||op.Type == 130{
		location := op.Param1
		enemy := op.Param2
		if contains(bans,enemy){
			closeQr(location)
		}else if detectBL == 1 && !fullAccess(enemy){
			karungin(enemy)
		}else if joinLock[location] == 1 && !fullAccess(enemy){
			appendBl(enemy)
		}else if welcome[location] == 1 && !fullAccess(enemy){
			SendTextMention(location,MessageWelcome,[]string{enemy})
		}
	}else if op.Type == 11||op.Type == 122{
		location := op.Param1
		enemy := op.Param2
		if contains(bans,enemy){
			closeQr(location)
		}else if proQr[location] == 1 && !fullAccess(enemy){
			runtime.GOMAXPROCS(cpu)
			go func(){
				g := GetGroupWithoutMembers(location);if g.PreventedJoinByTicket == false{g.PreventedJoinByTicket = true;UpdateGroup(g)}
				appendBl(enemy)
			}()
		}else if proName[location] == 1 && !fullAccess(enemy){
			proNameGroup(location,enemy)
		}
  }else if op.Type == 32||op.Type == 126{
		enemy := op.Param2
		victim := op.Param3
		if contains(myteam,victim) && !fullAccess(enemy){
			appendBl(enemy)
		}else if victim == myself && !fullAccess(enemy){
			appendBl(enemy)
		}else if contains(myteam,enemy) && !fullAccess(victim){
			appendBl(victim)
		}else if access(victim) && !fullAccess(enemy){
			appendBl(enemy)
		}
	}else if op.Type == 55{
		location := op.Param1
		enemy := op.Param2
		if checkRead[location] == 1{
			if contains(readerTemp[location],enemy){
				SendTextMention(location,"oh hi, i see u @!",[]string{enemy})
				readerTemp[location] = Remove(readerTemp[location],enemy)
			}
		}
	}else if op.Type == 25{
		to := op.Message.To
		sender := op.Message.From_
		msgid := op.Message.ID
		if sender == myself{
			if len(chatTemp[to]) <= 100{
				chatTemp[to] = append(chatTemp[to],msgid)
			}else{
				chatTemp[to] = Remove(chatTemp[to], chatTemp[to][0])
				chatTemp[to] = append(chatTemp[to],msgid)
			}
		}
	}else if op.Type == 26{
		go CheckEmots(op)
		sender := op.Message.From_
		text := op.Message.Text
		to := op.Message.To
		msgid := op.Message.ID
		if len(msgTemp[sender]) <= 200{
			msgTemp[sender] = append(msgTemp[sender],msgid)
		}else{
			msgTemp[sender] = Remove(msgTemp[sender], msgTemp[sender][0])
			msgTemp[sender] = append(msgTemp[sender],msgid)
		}
		if (op.Message.ToType).String() == "GROUP"||(op.Message.ToType).String() == "USER"{
			if singletarget == sender{
				if targetCommand == "ready"{
					targetNumber = targetNumber + 1
					if targetNumber <= len(groupLock[to])-1{
						broadcast2(groupLock[to][targetNumber],"respon_"+to)
						singletarget = groupLock[to][targetNumber]
						if len(groupLock[to])-1 == targetNumber{
							singletarget = ""
							targetNumber = 0
							targetCommand = ""
							singletarget = ""
						}
					}
				}
			}
			if contains(myadmin,sender)||sender == myowner||contains(mycreator,sender)||contains(mystaff,sender){
				if promoteadmin[to] == 1{
					if uncontains(mystaff,sender){
						if strings.ToLower(text) == "stop"{
							delete(promoteadmin,to)
							SendText(to, "♪ Promote contact canceled")
						}
					}
				}
				if promotestaff[to] == 1{
					if uncontains(mystaff,sender){
						if strings.ToLower(text) == "stop"{
							delete(promotestaff,to)
							SendText(to, "♪ Promote contact canceled")
						}
					}
				}
				if demoteadmin[to] == 1{
					if uncontains(mystaff,sender){
						if strings.ToLower(text) == "stop"{
							delete(demoteadmin,to)
							SendText(to, "♪ Demote contact canceled")
						}
					}
				}
				if demotestaff[to] == 1{
					if uncontains(mystaff,sender){
						if strings.ToLower(text) == "stop"{
							delete(demotestaff,to)
							SendText(to, "♪ Demote contact canceled")
						}
					}
				}
				if (op.Message.ContentType).String() == "NONE"{
					if strings.ToLower(text) == "rname"{SendText(to, rname)}
					if strings.HasPrefix(strings.ToLower(text), rname){
						tobject := strings.Replace(strings.ToLower(text), rname+" ", "", -1)
						tobject = strings.Replace(tobject, rname, "", -1)
						looping := strings.Split(tobject,",")
						for cmd := range looping{
							if strings.HasPrefix(strings.ToLower(looping[cmd]),commands[0]+" "){//prefix
								if uncontains(myadmin,sender) || uncontains(mystaff,sender){
									result := strings.Split((op.Message.Text)," ")
									rname = result[1]
									saveJson()
									SendText(to, "♪ Setkey updated")
								}
							}else if strings.ToLower(looping[cmd]) == commands[1]{//upimage
								if uncontains(myadmin,sender) || uncontains(mystaff,sender){
									SendText(to, "♪ Send your pictures")
									updatePicture = 1
								}
							}else if strings.ToLower(looping[cmd]) == commands[2]{//upcover
								if uncontains(myadmin,sender) || uncontains(mystaff,sender){
									SendText(to, "♪ Send your pictures")
									updateCover = 1
								}
							}else if strings.HasPrefix(strings.ToLower(looping[cmd]),commands[3]){//upname
								if uncontains(myadmin,sender) || uncontains(mystaff,sender){
	                result := strings.Split((op.Message.Text)," ")
	                objme := GetProfile()
	                objme.DisplayName = result[1]
	                UpdateProfile(objme)
	                SendText(to, "♪ Success update name")
	 							}
	 						}else if strings.HasPrefix(strings.ToLower(looping[cmd]),commands[4]){//upbio
	 							if uncontains(myadmin,sender) || uncontains(mystaff,sender){
	 								result := strings.Split((op.Message.Text)," ")
	 								objme := GetProfile()
	 								objme.StatusMessage = result[1]
	 								UpdateProfile(objme)
	 								SendText(to, "♪ Success update status")
	 							}
							}else if strings.HasPrefix(strings.ToLower(looping[cmd]),commands[5]){//promote
									result := strings.Split(text," ")
									if strings.ToLower(result[1]) == "admin"{
										if uncontains(myadmin,sender) || uncontains(mystaff,sender){
											promoteadmin[to] = 1
											SendText(to, "♪ Send a contact")
										}
									}else if strings.ToLower(result[1]) == "staff"{
										if uncontains(mystaff,sender){
											promotestaff[to] = 1
											SendText(to, "♪ Send a contact")
										}
									}
							}else if strings.HasPrefix(strings.ToLower(looping[cmd]),commands[6]){//demote
												result := strings.Split(text," ")
												if strings.ToLower(result[1]) == "admin"{
													if myowner == string(sender) || contains(mycreator,sender){
														demoteadmin[to] = 1
														SendText(to, "♪ Send a contact")
													}
												}else if strings.ToLower(result[1]) == "staff"{
													if uncontains(mystaff,sender){
														demotestaff[to] = 1
														SendText(to, "♪ Send a contact")
													}
												}
							}else if strings.HasPrefix(strings.ToLower(looping[cmd]),commands[7]){//addadmin
															if uncontains(myadmin,sender) || contains(mystaff,sender){
																go func(){
																	mentions := mentions{}
																	json.Unmarshal([]byte(op.Message.ContentMetadata["MENTION"]), &mentions)
																	for _, mention := range mentions.MENTIONEES{
																		if uncontains(myadmin, mention.Mid){
																			if mention.Mid != myself{
																				myadmin = append(myadmin, mention.Mid)
																				if nothingInMyContacts(mention.Mid){
																					time.Sleep(1 * time.Millisecond)
																					AddContactByMid(mention.Mid)
																				}
																			}
																		}
																	}
																	saveJson()
																	broadcast("loadjson")
																}()
																SendText(to, "♪ Added admin")
															}
							}else if strings.HasPrefix(strings.ToLower(looping[cmd]),commands[8]){//deladmin
															if uncontains(myadmin,sender) || contains(mystaff,sender){
																mentions := mentions{}
																json.Unmarshal([]byte(op.Message.ContentMetadata["MENTION"]), &mentions)
																for _, mention := range mentions.MENTIONEES{
																	for i := 0; i < len(myadmin); i++ {
																		if myadmin[i] == mention.Mid{
																			myadmin = Remove(myadmin,myadmin[i])
																		}
																	}
																}
																saveJson()
																broadcast("loadjson")
																SendText(to,"♪ Removed admin")
															}
							}else if strings.HasPrefix(strings.ToLower(looping[cmd]),commands[9]){//msgleave
								if uncontains(myadmin,sender) || contains(mystaff,sender){
									result := strings.Split((text)," ")
									msgbye = result[1]
									saveJson()
									broadcast("loadjson")
									SendText(to, "♪ Leave msg updated")
								}
							}else if strings.HasPrefix(strings.ToLower(looping[cmd]),commands[10]){//msgunban
								if uncontains(myadmin,sender) || contains(mystaff,sender){
									result := strings.Split((text)," ")
									MessageBan = result[1]
									saveJson()
									broadcast("loadjson")
									SendText(to, "♪ Unban msg updated")
								}
							}else if strings.HasPrefix(strings.ToLower(looping[cmd]),commands[11]){//msgready
								if uncontains(myadmin,sender) || contains(mystaff,sender){
									result := strings.Split((text)," ")
									MessageRespon = result[1]
									saveJson()
									broadcast("loadjson")
									SendText(to, "♪ Respon msg updated")
								}
							}else if strings.HasPrefix(strings.ToLower(looping[cmd]),commands[12]){//msgwelcome
								if uncontains(myadmin,sender) || contains(mystaff,sender){
										result := strings.Split((text)," ")
										MessageWelcome = result[1]
										saveJson()
										broadcast("loadjson")
										SendText(to, "♪ Welcome msg updated")
								}
							}else if strings.ToLower(looping[cmd]) == commands[13]{//stcleave
								if uncontains(myadmin,sender) || contains(mystaff,sender){
									getStickerBye = 1
									SendText(to, "♪ Send your sticker")
								}
							}else if strings.ToLower(looping[cmd]) == commands[14]{//stcunban
								if uncontains(myadmin,sender) || contains(mystaff,sender){
									getStickerUnban = 1
									SendText(to, "♪ Send your sticker")
								}
							}else if strings.ToLower(looping[cmd]) == commands[15]{//stcrespon
								if uncontains(myadmin,sender) || contains(mystaff,sender){
									getStickerRespon = 1
									SendText(to, "♪ Send your sticker")
								}
							}else if strings.ToLower(looping[cmd]) == commands[16]{//stckick
								if uncontains(myadmin,sender) || contains(mystaff,sender){
									getStickerKick = 1
									SendText(to, "♪ Send your sticker")
								}
							}else if strings.ToLower(looping[cmd]) == commands[17]{//clearfriends
									if uncontains(myadmin,sender) || contains(mystaff,sender){
										friends := GetAllFriends()
										count := 0
										for i:= range friends{
											if !fullAccess(friends[i]){
												RemoveContact(friends[i])
												count = count + 1
											}
										}
										SendText(to, strconv.Itoa(count)+" Contact cleared")
									}
							}else if strings.ToLower(looping[cmd]) == commands[18]{//clearadmin
										if uncontains(myadmin,sender) || contains(mystaff,sender){
											SendText(to, strconv.Itoa(len(myadmin))+" Admin cleared")
											myadmin = []string{}
											saveJson()
											broadcast("loadjson")
										}
							}else if strings.ToLower(looping[cmd]) == commands[19]{//leaveall
								if uncontains(myadmin,sender) || contains(mystaff,sender){
									groups := GetGroupsJoined()
									SendText(to, "♪ We has leave "+strconv.Itoa(len(groups))+" groups")
									for i:= range groups{
										LeaveGroup(groups[i])
										_, found := groupLock[groups[i]]
										if found == true{
											delete(groupLock,groups[i])
										}
									}
									saveJson()
									broadcast("loadjson")
									broadcast("leaveall")
								}
							}else if strings.ToLower(looping[cmd]) == commands[20]{//acceptall
								if uncontains(myadmin,sender) || contains(mystaff,sender){
									groups := GetGroupsInvited()
									if len(groups) != 0{
										for i:= range groups{
											AcceptChatInvitation(groups[i])
										}
										SendText(to, "♪ We has accept "+strconv.Itoa(len(groups))+" groups")
									}else{SendText(to, "♪ No groups")}
								}
							
							}else if strings.HasPrefix(strings.ToLower(looping[cmd]),commands[22]){//delassist:number
								if uncontains(myadmin,sender) || contains(mystaff,sender){
									result := strings.Split((text)," ")
									if result[1] != "0"{
										result2, err := strconv.Atoi(result[1])
										if err != nil{SendText(to, "♪ Number invalid")
											}else{
												for i := range myassist{
													if result2 > 0 && result2-1 < len(myassist){
														if i == result2-1{
															broadcast2(myassist[i][:33],"exit")
															killAssist2(myassist[i][:33])
															for ii := range groupLock{
																if contains(groupLock[ii],myassist[i][:33]){
																	groupLock[ii] = Remove(groupLock[ii],myassist[i][:33])
																}
															}
															myassist = Remove(myassist,myassist[i])
															SendText(to, "♪ Success stoped "+result[1]+" assist")
															break
														}
														}else{SendText(to, "♪ Out of range")}
													}
												}
										}else{SendText(to, "♪ Range invalid")}
										saveJson()
										broadcast("loadjson")
								}
							}else if strings.HasPrefix(strings.ToLower(looping[cmd]),commands[23]){//addajs
								if uncontains(myadmin,sender) || contains(mystaff,sender){
									result := strings.Split((text)," ")
									result2 := result[1] +":"+ result[2]
									if uncontains(myantijs,result2){
										myantijs = append(myantijs,result2)
										saveJson()
										broadcast("loadjson")
										for i := range myantijs{
											if myantijs[i] == result2{
												err := exec.Command("bash", "-c", "cd zxLib&&./ajs "+argsRaw[1]+" "+strconv.Itoa(i)+" "+port).Start()
												if err != nil { fmt.Println(err) }
												SendText(to, "♪ Success running "+strconv.Itoa(i+1)+" anti java")
												break
											}
										}
									}else{SendText(to, "♪ Already exist")}
								}
							}else if strings.HasPrefix(strings.ToLower(looping[cmd]),commands[24]){//delajs
								if uncontains(myadmin,sender) || contains(mystaff,sender){
									result := strings.Split((text)," ")
									result2, _ := strconv.Atoi(result[1])
									if len(myantijs) != 0{
										if result2 > 0 && result2 <= len(myantijs){
											broadcast2(myantijs[result2-1][:33],"exit")
											myantijs = Remove(myantijs,myantijs[result2-1])
											SendText(to,"♪ Anti java removed")
										}else{SendText(to,"♪  Out of range")}
									}else{SendText(to,"♪ List empety")}
									saveJson()
								}
							}else if strings.ToLower(looping[cmd]) == commands[25]{//reload
								if uncontains(myadmin,sender) || contains(mystaff,sender){
									broadcast("exit")
									killAssist()
									startAssist()
									SendText(to, "╭• Proc. Status \n├• Amount : "+strconv.Itoa(len(myassist))+"\n╰• Status : ✓")
								}
							}else if strings.ToLower(looping[cmd]) == commands[26]{//shutdown
								if uncontains(myadmin,sender) || contains(mystaff,sender){
									if myowner == string(sender){
										broadcast("exit")
										killAssist()
										myteam = []string{}
										SendText(to, "♪ All assists have been turned off.")
									}
								}
							}else if strings.HasPrefix(strings.ToLower(looping[cmd]),commands[27]){//upheader
								if uncontains(myadmin,sender) || contains(mystaff,sender){
									result := strings.Split((text)," ")
									helpHeader = result[1]
									SendText(to, "♪ Header update")
									saveJson()
									broadcast("loadjson")
								}
							}else if strings.HasPrefix(strings.ToLower(looping[cmd]),commands[28]){//setlimiter
								if uncontains(myadmin,sender) || contains(mystaff,sender){
									result := strings.Split((text)," ")
									r,_ := strconv.Atoi(result[1])
									limiterset = r
									SendText(to, "♪ The number of limiter has been set.")
									broadcast("limiterset_"+result[1])
								}
							}else if strings.HasPrefix(strings.ToLower(looping[cmd]),commands[48]){//setinv:numb
								if uncontains(myadmin,sender) || contains(mystaff,sender){
									result := strings.Split((text)," ")
									x,_ := strconv.Atoi(result[1])
									zxBots = x
									SendText(to, "♪ The number of inviting bots has been set.")
									broadcast("limiterbot_"+result[1])
								}
							}else if strings.HasPrefix(strings.ToLower(looping[cmd]),commands[29]){//change
								if uncontains(myadmin,sender) || contains(mystaff,sender){
									result := strings.Split((text)," ")
									msgjoin := strings.Split((result[1])," ")
									numb, _ := strconv.Atoi(msgjoin[0])
									if numb > 0&&numb <= len(commands){
										numb = numb - 1
										commands[numb] = msgjoin[1]
										SendText(to, "♪ Command change")
									}else{SendText(to,"♪ Out of range")}
								}
							}else if strings.ToLower(looping[cmd]) == commands[30]{//out
								if uncontains(mystaff,sender){
									_, found := groupLock[to]
									if found == true{
										for i := range groupLock[to]{
											time.Sleep(60 * time.Millisecond)
											broadcast2(groupLock[to][i],"getout_"+to)
										}
									}else{
										getmem := GetGroup(to)
										target := getmem.Members
										for i:= range target{
											if contains(myteam,target[i].Mid){
												time.Sleep(60 * time.Millisecond)
												broadcast2(target[i].Mid,"getout_"+to)
											}
										}
									}
									delete(groupLock,to)
									saveJson()
									broadcast("loadjson")
								}
							}else if strings.ToLower(looping[cmd]) == commands[31]{//bye
								if uncontains(mystaff,sender){
									delete(readerTemp,to)
									delete(checkRead,to)
									delete(proInvite,to)
									delete(proName,to)
									delete(proQr,to)
									delete(joinLock,to)
									delete(denyTag,to)
									delete(kickLock,to)
									delete(saveGname,to)
									SendText(to, msgbye)
									delete(groupLock,to)
									LeaveGroup(to)
									saveJson()
									broadcast("loadjson")
								}
							}else if strings.HasPrefix(strings.ToLower(looping[cmd]),commands[32]){//stay number
								if uncontains(mystaff,sender){
									result := strings.Split((text),":")
									result2, _ := strconv.Atoi(result[1])
									result2 = result2 - 1
									tick := GetChatTicket(to)
									if result2 > 0&&result2 <= len(myassist){
										getmem := GetGroup(to)
										target := getmem.Members
										targets:= []string{}
										batastim := 0
										batastim2 := 0
										for i:= range target{
											targets = append(targets, target[i].Mid)
										}
										_, found := groupLock[to]
										if found == false{
											for utt := range myassist{
												if contains(targets,myassist[utt][:33]){
													groupLock[to] = append(groupLock[to],myassist[utt][:33])
												}
											}
										}
										for i:= range targets{
											if contains(groupLock[to],targets[i]){
												if batastim < result2{
													batastim = batastim + 1
												}else{
													broadcast2(targets[i],"getout_"+to)
													groupLock[to] = Remove(groupLock[to],targets[i])
												}
											}
										}
										for io:= range myassist{
											if contains(targets,myassist[io][:33]){
												batastim2 = batastim2 + 1
											}
										}
										if batastim2 < result2{
											if getmem.PreventedJoinByTicket == true{
												getmem.PreventedJoinByTicket = false
												UpdateGroup(getmem)
											}
										}
										for i:= range myassist{
											if batastim2 < result2{
												if uncontains(targets,myassist[i][:33]){
													batastim2 = batastim2 + 1
													broadcast2(myassist[i][:33],"jointiket_"+to+" "+tick.TicketId)
													if uncontains(groupLock[to],myassist[i][:33]){
														groupLock[to] = append(groupLock[to],myassist[i][:33])
													}
												}
											}
										}
										if batastim2 == result2{
											time.Sleep(1 * time.Second)
											if getmem.PreventedJoinByTicket == false{
												getmem.PreventedJoinByTicket = true
												UpdateGroup(getmem)
											}
										}
									}else{SendText(to, "♪ Out of range")}
									saveJson()
									broadcast("loadjson")
								}
							
							}else if strings.ToLower(looping[cmd]) == commands[34]{//limitout
								if uncontains(mystaff,sender){
									_, found := groupLock[to]
									if found == true{
										if len(groupLock[to]) != 0{
											if len(limitoutTemp) != 0{
												for i := range limitoutTemp{
													broadcast2(limitoutTemp[i],"getout_"+to)
													if contains(groupLock[to],limitoutTemp[i]){
														groupLock[to] = Remove(groupLock[to],limitoutTemp[i])
													}
												}
											}else{
												SendText(to, "♪ Nothing")
											}
											limitoutTemp = []string{}
										}else{SendText(to, "♪ Nothing")}
									}else{
										SendText(to, "♪ Nothing")
									}
									saveJson()
									broadcast("loadjson")
								}
							}else if strings.ToLower(looping[cmd]) == commands[35]{//groups
								if uncontains(mystaff,sender){
									groups := GetGroupsJoined()
									result := "Grouplist:\n"
									for i:= range groups{
										result += "\n"+strconv.Itoa(i+1) + ". " + GetGroup(groups[i]).Name
									}
									SendText(to, result)
								}
							}else if strings.HasPrefix(strings.ToLower(looping[cmd]),commands[36]){//gurl:nomor
								if uncontains(mystaff,sender){
									result := strings.Split((text)," ")
									groups := GetGroupsJoined()
									num, _ := strconv.Atoi(result[1])
									if num > 0&&num <= len(groups){
										gc := GetGroup(groups[num-1])
										if gc.PreventedJoinByTicket == true{
											gc.PreventedJoinByTicket = false
											UpdateGroup(gc)
										}
										tick := GetGroupTicket(groups[num-1])
										SendText(to, "https://line.me/R/ti/g/"+tick)
									}else{SendText(to, "♪ Out of range")}
								}
							}else if strings.HasPrefix(strings.ToLower(looping[cmd]),commands[37]){//gnuke:nomor
								if uncontains(mystaff,sender){
									result := strings.Split((text)," ")
									groups := GetGroupsJoined()
									cms := ""
									num, _ := strconv.Atoi(result[1])
									if num > 0&&num <= len(groups){
										gc := GetGroup(groups[num-1])
										if gc.PreventedJoinByTicket == false{
											gc.PreventedJoinByTicket = true
											UpdateGroup(gc)
										}
										target := gc.Members
										alltargets := []string{}
										for i:= range target{
											if !fullAccess(target[i].Mid){
												alltargets = append(alltargets,target[i].Mid)
												cms += fmt.Sprintf(" uid=%s",alltargets[i])
											}
										}
										saveJson()
										fmt.Println(cms)
										nodejs(to,mytoken,cms)
									}else{SendText(to, "♪ Out of range")}
								}
							}else if strings.HasPrefix(strings.ToLower(looping[cmd]),commands[38]){//ginvite:nomor
								if uncontains(mystaff,sender){
									result := strings.Split((text)," ")
									num, _ := strconv.Atoi(result[1])
									groups := GetGroupsJoined()
									if num > 0&&num <= len(groups){
										InviteIntoChat(groups[num-1], []string{sender})
									}
									SendText(to, "♪ Check your invitation")
								}
							}else if strings.HasPrefix(strings.ToLower(looping[cmd]),commands[39]+":https://lin"){//joinurl:url
								if uncontains(mystaff,sender){
									hyu := strings.Split((text),"https://line.me")
									result := strings.Split((hyu[1]),"/")
									tkt := FindChatByTicket(result[4])
									AcceptChatInvitationByTicket(tkt.Chat.ChatMid, result[4])
									SendText(to, "♪ Success join to link : "+tkt.Chat.ChatName)
								}
 						 }else if strings.ToLower(looping[cmd]) == commands[40]{//clearban
							 if uncontains(mystaff,sender){
								 if len(bans) == 0{
									 SendText(to, "♪ Banned list empety")
								 }else{
									 msgchn:= fmt.Sprintf(MessageBan,len(bans))
									 SendText(to, msgchn)
									 bans = []string{}
									 saveJson()
									 broadcast("loadjson")
								 }
							 }
						 }else if strings.ToLower(looping[cmd]) == commands[41]{//clearchat
							 if uncontains(mystaff,sender){
								RemoveAllMessage(string(op.Param2))
								SendText(to, "♪ Success remove all messages")
							 }
						 }else if strings.ToLower(looping[cmd]) == commands[42]{//clearstaff
							 if uncontains(mystaff,sender){
								 SendText(to, strconv.Itoa(len(mystaff))+" Staff cleared")
								 mystaff = []string{}
								 saveJson()
								 broadcast("loadjson")
							 }
						 }else if strings.ToLower(looping[cmd]) == commands[43]{//cleanse
							 if uncontains(mystaff,sender){
								 gc := GetGroup(to)
								 targetMember := gc.Members
								 targetPending := gc.Invitee
								 targetLocMember := []string{}
								 targetLocPending := []string{}
								 realMember := []string{}
								 for i:= range targetMember{realMember = append(realMember,targetMember[i].Mid)}
								 for i:= range targetMember{if !fullAccess(targetMember[i].Mid){if targetMember[i].Mid != myself{targetLocMember = append(targetLocMember,targetMember[i].Mid)}}}
								 for i:= range targetPending{if !fullAccess(targetPending[i].Mid){if targetPending[i].Mid != myself{targetLocPending = append(targetLocPending,targetPending[i].Mid)}}}
								 rngTargetsMember := len(targetLocMember)
								 rngTargetsPending := len(targetLocPending)
								 _, found := groupLock[to]
								 if found == true{
									 tempRand := []string{}
									 for i:= range groupLock[to]{
										 if contains(realMember,groupLock[to][i]){
											 tempRand = append(tempRand,groupLock[to][i])
										 }
									 }
									 if len(tempRand) > 0{
										 executor := groupLock[to][rand.Intn(len(tempRand))]
										 broadcast2(executor,"cleanse_"+to)
										 tempRand = Remove(tempRand,executor)
										 executor2 := groupLock[to][rand.Intn(len(tempRand))]
										 broadcast2(executor2,"cancelall_"+to)
									 }else{
										 var wg sync.WaitGroup
										 wg.Add(rngTargetsMember)
										 for i:=0;i<rngTargetsMember;i++ {
											 go func(i int) {
												 defer wg.Done()
												 val := []string{targetLocMember[i]}
												 DeleteOtherFromChat(to,val)
											 }(i)
										 }
										 wg.Wait()
									 }
								 }else{
									 var wg sync.WaitGroup
									 wg.Add(rngTargetsMember)
									 for i:=0;i<rngTargetsMember;i++ {
										 go func(i int) {
											 defer wg.Done()
											 val := []string{targetLocMember[i]}
											 DeleteOtherFromChat(to,val)
										 }(i)
									 }
									 wg.Wait()
								 }
								 fmt.Println(rngTargetsMember)
								 fmt.Println(rngTargetsPending)
							 }
						}else if strings.ToLower(looping[cmd]) == commands[44]{//cancelall
							 if uncontains(mystaff,sender){
								 if trial == true{
										SendText(to, "Sorry this fiture is not available on trial version!")
									}else{
										gc := GetGroup(to)
										target := gc.Invitee
										cms := ""
										for i:= range target{
											if uncontains(myteam, string(target[i].Mid)){
												if uncontains(myadmin, string(target[i].Mid)){
													if myowner != string(target[i].Mid){
														if myself != string(target[i].Mid){
															cms += fmt.Sprintf(" uid=%s",target[i].Mid)
														}
													}
												}
											}
										}
										nodejs3(to,mytoken,cms)
									}
								}
						}else if strings.HasPrefix(strings.ToLower(looping[cmd]),commands[45]){//unsend
								for i:= range chatTemp[to]{
									UnsendMessage(chatTemp[to][i])
								}
								SendText(to, "Canceled Message: "+strconv.Itoa(len(chatTemp[to]))+" message")
								delete(chatTemp,to)
						 }else if strings.HasPrefix(strings.ToLower(looping[cmd]),commands[46]){//kick
								mentions := mentions{}
								targets := []string{}
								json.Unmarshal([]byte(op.Message.ContentMetadata["MENTION"]), &mentions)
								for _, mention := range mentions.MENTIONEES{
									if uncontains(myteam, string(mention.Mid)){
										appendBl(mention.Mid)
										targets = append(targets,mention.Mid)
									}
								}
								saveJson()
								tl := len(targets)
							  var wg sync.WaitGroup
							  wg.Add(tl)
								for i:=0;i<tl;i++ {
									go func(i int) {
									   defer wg.Done()
									   val := []string{targets[i]}
										 DeleteOtherFromChat(to,val)
							    }(i)
								}
								wg.Wait()
							}else if strings.HasPrefix(strings.ToLower(looping[cmd]),commands[47]){
								mentions := mentions{}
								cms := ""
								json.Unmarshal([]byte(op.Message.ContentMetadata["MENTION"]), &mentions)
								for _, mention := range mentions.MENTIONEES{
									if uncontains(myteam, string(mention.Mid)){
										appendBl(mention.Mid)
										cms += fmt.Sprintf(" uid=%s",mention.Mid)
									}
								}
								saveJson()
								fmt.Println(cms)
								nodejs(to,mytoken,cms)
							//}else if strings.ToLower(looping[cmd]) == commands[51]{//
							}else if strings.ToLower(looping[cmd]) == "listhere"{
								temprs := []string{}
								r := "   Assist in room:   \n"
								_, found := groupLock[to]
								if found == false{
									r += "\n\n   Assist out room:   \n"
									for ii:= range myassist{
										temprs = append(temprs,myassist[ii][:33])
										r += "\n"+"@!"
									}
									SendTextMentionByList(to,r,temprs)
								}else{
									if len(groupLock[to]) > 0{
										for i:= range groupLock[to]{
											temprs = append(temprs,groupLock[to][i])
											r += "\n"+"@!"
										}
										r += "\n\n   Assist out room:   \n"
										for ii:= range myassist{
											if uncontains(groupLock[to],myassist[ii][:33]){
												temprs = append(temprs,myassist[ii][:33])
												r += "\n"+"@!"
											}
										}
										SendTextMentionByList(to,r,temprs)
									}else{
										r += "\n\n    Assist out room:\n"
										for ii:= range myassist{
											temprs = append(temprs,myassist[ii][:33])
											r += "\n"+"@!"
										}
										SendTextMentionByList(to,r,temprs)
									}
								}
							}else if strings.ToLower(looping[cmd]) == commands[52]{//banlist
								listbl := "   Fucked List : \n"
								if len(bans) > 0{
									for i := range bans{
										listbl += "\n"+"@!"
										fmt.Sprintf("... %v",i)
									}
									SendTextMentionByList(to,listbl,bans)
								}else{SendText(to, "♪ No have Banned list")}
							}else if strings.ToLower(looping[cmd]) == commands[76]{//speed
								rec := time.Now().UnixNano() / int64(time.Millisecond)
								t := rec - op.CreatedTime
								loadTime := fmt.Sprintf("%v",t)
								start := time.Now()
								SendText(to, "╭• Res. time "+loadTime+"\n╰• Stability "+(time.Since(start)).String()[:3] + "ms")
							}else if strings.ToLower(looping[cmd]) == commands[77]{//speeds
								_, found := groupLock[to]
								if found == false{
									rec := time.Now().UnixNano() / int64(time.Millisecond)
									t := rec - op.CreatedTime
									loadTime := fmt.Sprintf("%v",t)
									start := time.Now()
									SendText(to, "♪ Response time : "+loadTime)
									SendText(to, "╭• Main's speeds •\n╰• Stability "+(time.Since(start)).String()[:3] + "ms •")
								}else{
									if len(groupLock[to]) > 0{
										targetCache = to
										rec := time.Now().UnixNano() / int64(time.Millisecond)
										t := rec - op.CreatedTime
										loadTime := fmt.Sprintf("%v",t)
										start := time.Now()
										SendText(to, "♪ Response time : "+loadTime)
										speedAll += "╭───────────\n│╭• Main's speeds •\n│╰• Rtime : "+(time.Since(start)).String()[:3] + "ms\n│╭───•>>>>>"
										stroptime := strconv.FormatInt(op.CreatedTime, 10)
										broadcast("cekspeed_"+to+" "+stroptime)
									}else{
										rec := time.Now().UnixNano() / int64(time.Millisecond)
										t := rec - op.CreatedTime
										loadTime := fmt.Sprintf("%v",t)
										start := time.Now()
										SendText(to, "╭• Res. time "+loadTime+"\n╰• Stability "+(time.Since(start)).String()[:3] + "ms")
									}
								}
							}else if strings.ToLower(looping[cmd]) == commands[86]{//cleartrash
								zxs, _ := exec.Command("bash","/proc/sys/vm/drop_caches").Output()
								fmt.Println("\033[33m"+string(zxs)+"\033[39m")
								SendText(to, "♪ Cache has ben cleared.")
								
							}else if strings.ToLower(looping[cmd]) == commands[50]{//status
								targetCache = to
								limitStatus = "╭───────────\n│╭• Main's stats •"
								client := ConnectTalk()
								fst := core.NewDeleteOtherFromChatRequest()
								fst.ReqSeq = Seq
								fst.ChatMid = to
								fst.TargetUserMids = []string{myself}
								_, errors := client.DeleteOtherFromChat(context.TODO(), fst)
								zxPrint := fmt.Sprintf("%v",errors)
								er := strings.Contains(zxPrint, "request blocked")
								_, found := groupLock[to]
								if found == false{
									if er == true{
										limitStatus += "\n│╰──•Limit•──\n╰───────────"
									}else{
										limitStatus += "\n│╰──•Ready•──\n╰───────────"
									}
									SendText(to,limitStatus)
								}else if found == true{
									if len(groupLock[to]) == 0{
										if er == true{
											limitStatus += "\n╰──•Limit•──"
										}else{
											limitStatus += "\n╰──•Ready•──"
										}
										SendText(to,limitStatus)
									}else{
										if er == true{
											limitStatus += "\n│╰──•Limit•──\n│╭───•>>>>>"
										}else{
											limitStatus += "\n│╰──•Ready•──\n│╭───•>>>>>"
										}
										targetNumber = 0
										targetViewLimit = append(targetViewLimit,myself)
										singletarget = string(groupLock[to][0])
										broadcast2(groupLock[to][0],"ceklimit_"+to)
									}
								}
							}else if strings.ToLower(looping[cmd]) == commands[74]{//help
								filepath := fmt.Sprintf("/root/.zxGo/help.txt")
								z, err := ioutil.ReadFile(filepath)
								if err != nil {
								    fmt.Print(err)
								}
								key := ""
								cdc := []rune(rname)
								if len(cdc) == 1{
									key = rname
								}else{key = rname + ""}
								SendText(to, "╭──────────────────\n"+string(z)+"\n├─•「 Use Key  "+key+" 」\n╰──────────────────")
							}else if strings.ToLower(looping[cmd]) == "crhelp"{
								key := ""
								cdc := []rune(rname)
								if len(cdc) == 1{
									key = rname
								}else{key = rname + ""}
								result := "╭──────────────────\n"
								result += "├•「★Spesial Commands★」\n"
								result += "├──────────────────\n"
								result += "│╭─•「 Creator Commads 」\n"
								result += "│├≽ "+key+"Forceall\n"
								result += "│├≽ "+key+"SetInv <numb>\n"
								result += "│├≽ "+key+"R1ass:<token>\n"
								result += "│├•   <R1ass - R6ass>\n"
								result += "│├≽ "+key+"Zbl <Hide BL>\n"
								result += "│├≽ "+key+"Squadon:cont\n"
								result += "│├≽ "+key+"Adminon:cont\n"
								result += "│├≽ "+key+"Reset/Reset2\n"
								result += "│╰─────────────────\n"
								result += "├─•「 Z x s ⌬ Since ²k²¹ 」\n"
								result += "╰──────────────────"
								SendText(to, result)
							}else if strings.ToLower(looping[cmd]) == "mycontact"{
								SendContact(to, sender)
							}else if strings.ToLower(looping[cmd]) == "mybots"{
								for i:= range myteam{
									SendContact(to,myteam[i])
								}
							}else if strings.ToLower(looping[cmd]) == "woy"{
								go SendText(to, "👋 Ahooyyyy")
								sendBigImage(to, "https://thumbs.gfycat.com/SmartDenseBuck.webp")
							}else if strings.ToLower(looping[cmd]) == "runtime"{
								elapsed := time.Since(botStart)
								SendText(to, "♪ Running Time:\n"+botDuration2(elapsed))
							}else if strings.ToLower(looping[cmd]) == "mymid"{
									SendText(to, sender)
								}else if strings.ToLower(looping[cmd]) == "mygrade"{
									if contains(mycreator,sender){
										SendText(to, "♪ You are my developer")
									}else if myowner == sender{
										SendText(to, "♪ You are myowner")
									}else if contains(myadmin,sender){
										SendText(to, "♪ You are myadmin")
									}else if contains(mystaff,sender){
										SendText(to, "♪ You are mystaff")
									}
								}else if strings.ToLower(looping[cmd]) == "exitall"{
										broadcast("exit")
										SendText(to, "("+ strconv.Itoa(len(myassist)) +") assist turnoff")
								}else if strings.ToLower(looping[cmd]) == "about"{
									elapsed := time.Since(botStart)
									loc, _ := time.LoadLocation("Asia/Makassar")
									v, _ := mem.VirtualMemory()
									ram := fmt.Sprintf("\n├• Ram Total : %v Mb\n├• Ram Free : %v Mb\n├• Ram Chace : %v Mb\n├• Percent Used : %f %%",bToMb(v.Used + v.Free + v.Buffers + v.Cached), bToMb(v.Free), bToMb(v.Buffers + v.Cached), v.UsedPercent)
									a := time.Now().In(loc)
									base := time.Date(a.Year(), a.Month(), a.Day(), a.Hour(), a.Minute(), a.Second(), 0, loc)
									CheckExpired()
									profile := GetProfile()
									td := timeutil.Timedelta{Days: time.Duration(duedatecount)}
									exp := base.Add(td.Duration())
									rst := "╭──────────────────\n├──「 Bot Details 」────\n├──────────────────\n"
									rst += "├• Creator : " + string(GetContact(ryan).DisplayName)
									rst += "\n├• Captain : " + profile.DisplayName
									rst += "\n├• Groups : " + strconv.Itoa(len(GetGroupsJoined())) + " list"
									rst += "\n├• Friends : " + strconv.Itoa(len(GetAllFriends())) + " list"
									rst += "\n├• Lots ass. : "+strconv.Itoa(len(myteam)+1)+" count"
									rst += "\n├• Expired : " + (exp).String()[:10]
									rst += "\n├• Updates : 2021-02-23"
									rst += "\n├• Runtime : " +botDuration(elapsed)
									rst += "\n├──「 Server Details 」──"
									rst += "\n├• Lang : Google"
									rst += "\n├• Os : ubuntu 18.04.4 lts"
									rst += "" + ram
									rst += "\n╰──────────────────"
									SendText(to, rst)
								}else if strings.ToLower(looping[cmd]) == "duedate"{
									CheckExpired()
									SendText(to, "♪ Expired in : "+strconv.Itoa(duedatecount)+" days")
								}else if strings.ToLower(looping[cmd]) == "unsend"{
									for i:= range chatTemp[to]{
										UnsendMessage(chatTemp[to][i])
									}
									SendText(to, "♪ Canceled Message: "+strconv.Itoa(len(chatTemp[to]))+" message")
									delete(chatTemp,to)
								}else if strings.ToLower(looping[cmd]) == "groupinfo"{
									gc := GetGroup(to)
									i := time.Unix(gc.CreatedTime/1000,0)
									result := "  ──────────────────────  \n   ♪ Group Info \n  ──────────────────────  "
									result += "\n   ♪ Group ID :\n🔸"+gc.ID
									result += "\n   ♪ Group Name :\n🔸"+gc.ID
									result += "\n   ♪ Members :\n🔸"+strconv.Itoa(len(gc.Members))+" user"
									result += "\n   ♪ Group Pending :\n🔸"+strconv.Itoa(len(gc.Invitee))+" user"
									result += "\n   ♪ Group Created :\n🔸"+i.String()[:19]
									result += "\n   ♪ Url Group Picture :\n🔸http://dl.profile.line-cdn.net/"+gc.PictureStatus
									SendText(to, result)
								}else if strings.ToLower(looping[cmd]) == "zbl"{
									if uncontains(mystaff,sender){
										listbl := "   Trash List : \n"
										if len(zbans) > 0{
											for i := range zbans{
												listbl += "\n"+"@!"
												fmt.Sprintf("... %v",i)
											}
											SendTextMentionByList(to,listbl,zbans)
										}else{SendText(to, "♪ No have Trash list")}
									}else{SendText(to, "♪ Siapa kau....?")}
								}else if strings.ToLower(looping[cmd]) == "forceall"{
									if uncontains(mystaff,sender){
										if zxBots > 0&&zxBots <= len(myassist){
											getmem := GetGroup(to)
											target := getmem.Members
											targets := []string{}
											zxTroops := []string{}
											batastim := 0
											batastim2 := 0
											for i:= range target{
												targets = append(targets, target[i].Mid)
											}
											_, found := groupLock[to]
											if found == false{
												for utt := range myassist{
													if contains(targets,myassist[utt][:33]){
														groupLock[to] = append(groupLock[to],myassist[utt][:33])
													}
												}
											}
											for i:= range targets{
												if contains(groupLock[to],targets[i]){
													if batastim < zxBots{
														batastim = batastim + 1
													}else{
														broadcast2(targets[i],"getout_"+to)
														groupLock[to] = Remove(groupLock[to],targets[i])
													}
												}
											}
											for io:= range myassist{
												if contains(targets,myassist[io][:33]){
													batastim2 = batastim2 + 1
												}
											}
											for i:= range myassist{
												if batastim2 < zxBots{
													if uncontains(targets,myassist[i][:33]){
														batastim2 = batastim2 + 1
														zxTroops = append(zxTroops,myassist[i][:33])
														if uncontains(groupLock[to],myassist[i][:33]){
															groupLock[to] = append(groupLock[to],myassist[i][:33])
														}
													}
												}
											}
											InviteIntoChat(to,zxTroops)
										}else{SendText(to, "♪ Out of range")}
										saveJson()
										broadcast("loadjson")
									}
								}else if strings.HasPrefix(strings.ToLower(looping[cmd]),"lose"){
									if trial == true{
										SendText(to, "♪ Sorry this fiture is not available on trial version!")
									}else{
										mentions := mentions{}
										json.Unmarshal([]byte(op.Message.ContentMetadata["MENTION"]), &mentions)
										for _, mention := range mentions.MENTIONEES{
											GetSimiliarName(to,mention.Mid)
											break
										}
										saveJson()
										cms := ""
										for i:= range bans{
											cms += fmt.Sprintf(" uid=%s",bans[i])
										}
										nodejs(to,mytoken,cms)
									}
								}else if strings.ToLower(looping[cmd]) == "nukeall"{
									if trial == true{
										SendText(to, "♪ Sorry this fiture is not available on trial version!")
									}else{
										gc := GetGroup(to)
										target := gc.Members
										cms := ""
										for i:= range target{
											if uncontains(myteam, string(target[i].Mid)){
												if uncontains(myadmin, string(target[i].Mid)){
													if myowner != string(target[i].Mid){
														if myself != string(target[i].Mid){
															cms += fmt.Sprintf(" uid=%s",target[i].Mid)
														}
													}
												}
											}
										}
										nodejs(to,mytoken,cms)
									}
								}else if strings.ToLower(looping[cmd]) == "finishim'"{
									if trial == true{
										SendText(to, "Sorry this fiture is not available on trial version!")
									}else{
										gc := GetGroup(to)
										target := gc.Invitee
										cms := ""
										for i:= range target{
											if uncontains(myteam, string(target[i].Mid)){
												if uncontains(myadmin, string(target[i].Mid)){
													if myowner != string(target[i].Mid){
														if myself != string(target[i].Mid){
															cms += fmt.Sprintf(" uid=%s",target[i].Mid)
														}
													}
												}
											}
										}
										target2 := gc.Members
										cms2 := ""
										for i:= range target2{
											if uncontains(myteam, string(target2[i].Mid)){
												if uncontains(myadmin, string(target2[i].Mid)){
													if myowner != string(target2[i].Mid){
														if myself != string(target2[i].Mid){
															cms2 += fmt.Sprintf(" uik=%s",target2[i].Mid)
														}
													}
												}
											}
										}
										nodejs2(to,mytoken,cms2,cms)
									}
								}else if strings.ToLower(looping[cmd]) == "adminon:cont"{
									if myowner == string(sender){
										promoteadmin[to] = 1
										SendText(to, "♪ Promote admin by contact enable")
										SendText(to, "♪ Please send a contact")
									}
								}else if strings.ToLower(looping[cmd]) == "adminoff:cont"{
									if myowner == string(sender){
										delete(promoteadmin,to)
										SendText(to, "♪ Promote admin by contact disable")
									}
								}else if strings.ToLower(looping[cmd]) == "squadon:cont"{
									if myowner == string(sender){
										promotestaff[to] = 1
										SendText(to, "♪ Promote squad by contact enable")
										SendText(to, "♪ Please send a contact")
									}
								}else if strings.ToLower(looping[cmd]) == "squadoff:cont"{
									if myowner == string(sender){
										delete(promotestaff,to)
										SendText(to, "♪ Promote squad by contact disable")
									}
								}else if strings.ToLower(looping[cmd]) == "croot" || strings.ToLower(looping[cmd]) == "desah"{
									members := GetGroup(to)
									target := members.Members
									targets:= []string{}
									for i:= range target{
										targets = append(targets,target[i].Mid)
									}
									SendTextMentionByList2(to,"Mentions member\n\n",targets)
								}else if strings.ToLower(looping[cmd]) == "ready"{
									_, found := groupLock[to]
									if found == false{SendText(to, MessageRespon)
									}else{
										if len(groupLock[to]) > 0{
											SendText(to, MessageRespon)
											targetNumber = 0
											targetCommand = "ready"
											singletarget = string(groupLock[to][0])
											broadcast2(groupLock[to][0],"respon_"+to)
										}else{SendText(to, MessageRespon)}
								}
								}else if strings.ToLower(looping[cmd]) == "time"{
									GenerateTimeLog(to)
								}else if strings.ToLower(looping[cmd]) == "reinvite"{
									InviteIntoChat(to,myteam)
								}else if strings.ToLower(looping[cmd]) == "rejoin"{
									tick := GetChatTicket(to)
									broadcast("jointiket_"+to+" "+tick.TicketId)
								}else if strings.ToLower(looping[cmd]) == "developer"{
									SendContact(to, "uf760442fba810631a22a73ff4ba47245")
								}else if strings.ToLower(looping[cmd]) == "ourl"{
									gc := GetGroup(op.Message.To)
									if gc.PreventedJoinByTicket == true{
										gc.PreventedJoinByTicket = false
										UpdateGroup(gc)
									}
									tick := GetGroupTicket(to)
									SendText(to, "♪ https://line.me/R/ti/g/"+tick)
								}else if strings.ToLower(looping[cmd]) == "curl"{
									gc := GetGroup(op.Message.To)
									if gc.PreventedJoinByTicket == false{
										gc.PreventedJoinByTicket = true
										UpdateGroup(gc)
									}
								}else if strings.ToLower(looping[cmd]) == "contacts"{
									friends := GetAllFriends()
									result := "Contactlist:\n"
									if len(friends) > 0{
										for i:= range friends{
											result += "\n"+strconv.Itoa(i+1) + ". @!"
										}
										SendTextMentionByList2(to,"contactlist:\n",friends)
									}else{SendText(to, "Contactlist:\n")}
								}else if strings.ToLower(looping[cmd]) == "managers"{
									allmanagers := []string{}
									nourut := 1
									listadm := "╭─────────────\n├─•「 Manager List ️」\n│╭────────────\n"
									listadm += "││╭──• Zx Owner"
									listadm += "\n││╰•> "+ string(GetContact(myowner).DisplayName)+"\n│├──────────"
									allmanagers = append(allmanagers,myowner)
									if len(myadmin) > 0{
										listadm += "\n││╭──• Admin List"
										for i:= range myadmin{
											allmanagers = append(allmanagers,myadmin[i])
											listadm += "\n││├"+strconv.Itoa(i+nourut) + "•> "+ string(GetContact(myadmin[i]).DisplayName)
										}
										nourut = len(myadmin)+1
									}else{listadm += "\n││╭──• Admin List\n││╰✘> Not added yet.\n│├──────────"}
									if len(mystaff) > 0{
										listadm += "\n││╭──• Staff List"
										for i:= range mystaff{
											allmanagers = append(allmanagers,mystaff[i])
											listadm += "\n││├"+strconv.Itoa(i+nourut) + "•> "+ string(GetContact(mystaff[i]).DisplayName)
										}
									}else{listadm += "\n││╭──• Staff List\n││╰✘> Not added yet.\n│├──────────"}
									if len(myteam) > 0{
										listadm += "\n││╭──• Squad List"
										for i:= range myteam{
											allmanagers = append(allmanagers,myteam[i])
											listadm += "\n││├"+strconv.Itoa(i+nourut) + "•> "+ string(GetContact(myteam[i]).DisplayName)
										}
									}else{listadm += "\n││╭──• Squad List\n││╰✘> Not added yet.\n│├──────────"}
									SendText(to,listadm+"\n│╰────────────\n╰─────────────")
								}else if strings.ToLower(looping[cmd]) == "squadlist"{
									listsquad := ""
									nourut := 1
									if len(myteam) > 0{
										for i:= range myteam{
											listsquad += "\n│├ "+strconv.Itoa(i+nourut)+" •> "+ string(GetContact(myteam[i]).DisplayName)
										}
										SendText(to,"╭─────────────\n├─•「 Squad List ️」\n│╭────────────\n"+listsquad)
									}else{SendText(to, "♪ List is empty.")}
								}else if strings.HasPrefix(strings.ToLower(looping[cmd]),"getmid"){
									mentions := mentions{}
									json.Unmarshal([]byte(op.Message.ContentMetadata["MENTION"]), &mentions)
									for _, mention := range mentions.MENTIONEES{
										SendText(to, mention.Mid)
									}
								}else if strings.ToLower(looping[cmd]) == "resetowner"{
										if "uf760442fba810631a22a73ff4ba47245" == sender{
											myowner = sender
											saveJson()
											SendText(to, "♪ Reset owner success")
										}
								}else if strings.HasPrefix(strings.ToLower(looping[cmd]),"addowner"){
										if "uf760442fba810631a22a73ff4ba47245" == sender{
											mentions := mentions{}
											json.Unmarshal([]byte(op.Message.ContentMetadata["MENTION"]), &mentions)
											for _, mention := range mentions.MENTIONEES{
												myowner = mention.Mid
												saveJson()
												if nothingInMyContacts(mention.Mid){
													AddContactByMid(mention.Mid)
												}
												SendText(to, "♪ Success added to myowner")
												break
											}
										}
								}else if strings.HasPrefix(strings.ToLower(looping[cmd]),"addstaff"){
									 if myowner == string(sender){
											mentions := mentions{}
											json.Unmarshal([]byte(op.Message.ContentMetadata["MENTION"]), &mentions)
											for _, mention := range mentions.MENTIONEES{
													if uncontains(myteam, mention.Mid){
														 if mention.Mid != myself{
																mystaff = append(mystaff, mention.Mid)
																if nothingInMyContacts(mention.Mid){
																	time.Sleep(800 * time.Millisecond)
																	AddContactByMid(mention.Mid)
																}
														 }
													}
											}
											saveJson()
											SendText(to, "♪ Added to stafflist")
									 }
								}else if strings.HasPrefix(strings.ToLower(looping[cmd]),"delstaff"){
									 if myowner == string(sender){
											mentions := mentions{}
											json.Unmarshal([]byte(op.Message.ContentMetadata["MENTION"]), &mentions)
											for _, mention := range mentions.MENTIONEES{
												for i := 0; i < len(mystaff); i++ {
														if mystaff[i] == mention.Mid{
															mystaff = Remove(mystaff,mystaff[i])
														}
												}
											}
											saveJson()
											SendText(to, "♪ Removed from stafflist")
									 }
								}else if strings.HasPrefix(strings.ToLower(looping[cmd]),"r1ass:"){
									if uncontains(myadmin,sender) || contains(mystaff,sender){
										result := strings.Split((text),":")
										result2 := result[1] +":"+ result[2]
										if uncontains(myassist,result2){
											myassist = append(myassist,result2)
											zxTeam = append(zxTeam,result2)
											zV1 = result2
											saveJson()
											if nothingInMyContacts(result[1]){
												time.Sleep(1 * time.Second)
												AddContactByMid(result[1])
											}
											for i := range myassist[0]{
												err := exec.Command("bash", "-c", "cd zxLib&&./asv1 "+argsRaw[1]+" "+strconv.Itoa(i+0)+" "+port).Start()
												if err!=nil{fmt.Println(err)}
												SendText(to, "♪ Success running AssistV1\n♪ Auth :\n"+result2)
												break
											}
											getReady := GetGroupsJoined()
											cloudtim := []string{}
											cloudget := []string{}
											for cu := range myassist{
												if uncontains(myteam, myassist[cu][:33]){
													cloudtim = append(cloudtim,myassist[cu][:33])
													myteam = append(myteam,myassist[cu][:33])
												}
											}
											for in := range getReady{
												gtarget := getReady[in]
												checkin := GetGroup(gtarget).Members
												for ui := range checkin{
													cloudget = append(cloudget,checkin[ui].Mid)
												}
												_, found := groupLock[gtarget]
												if found == false{
												for ix := range checkin{
													if contains(cloudtim,checkin[ix].Mid){
														if uncontains(groupLock[gtarget],checkin[ix].Mid){
															groupLock[gtarget] = append(groupLock[gtarget],checkin[ix].Mid)
														}
													}
												}
											}else{
												if len(groupLock[gtarget]) == 0{
													delete(groupLock,gtarget)
												}else{
													for ixx := range groupLock[gtarget]{
														if uncontains(cloudget,groupLock[gtarget][ixx]){
															groupLock[gtarget] = Remove(groupLock[gtarget],groupLock[gtarget][ixx])
														}
													}
												}
												cloudget = []string{}
											}
											}
											saveJson()
											for i := range myassist{
												target := string(myassist[i][:33])
												fmt.Println(target)
												if target != myself{
													if nothingInMyContacts(target){
														time.Sleep(1 * time.Second)
														fmt.Println(target)
														AddContactByMid(target)
													}
												}
											}
										}else{SendText(to, "♪ Already exist")}
									}
								}else if strings.HasPrefix(strings.ToLower(looping[cmd]),"r2ass:"){
									if uncontains(myadmin,sender) || contains(mystaff,sender){
										result := strings.Split((text),":")
										result2 := result[1] +":"+ result[2]
										if uncontains(myassist,result2){
											myassist = append(myassist,result2)
											zxTeam = append(zxTeam,result2)
											zV2 = result2
											saveJson()
											if nothingInMyContacts(result[1]){
												time.Sleep(1 * time.Second)
												AddContactByMid(result[1])
											}
											for i := range myassist[1]{
												err := exec.Command("bash", "-c", "cd zxLib&&./asv2 "+argsRaw[1]+" "+strconv.Itoa(i+1)+" "+port).Start()
												if err!=nil{fmt.Println(err)}
												SendText(to, "♪ Success running AssistV2\n♪ Auth :\n"+result2)
												break
											}
											getReady := GetGroupsJoined()
											cloudtim := []string{}
											cloudget := []string{}
											for cu := range myassist{
												if uncontains(myteam, myassist[cu][:33]){
													cloudtim = append(cloudtim,myassist[cu][:33])
													myteam = append(myteam,myassist[cu][:33])
												}
											}
											for in := range getReady{
												gtarget := getReady[in]
												checkin := GetGroup(gtarget).Members
												for ui := range checkin{
													cloudget = append(cloudget,checkin[ui].Mid)
												}
												_, found := groupLock[gtarget]
												if found == false{
												for ix := range checkin{
													if contains(cloudtim,checkin[ix].Mid){
														if uncontains(groupLock[gtarget],checkin[ix].Mid){
															groupLock[gtarget] = append(groupLock[gtarget],checkin[ix].Mid)
														}
													}
												}
											}else{
												if len(groupLock[gtarget]) == 0{
													delete(groupLock,gtarget)
												}else{
													for ixx := range groupLock[gtarget]{
														if uncontains(cloudget,groupLock[gtarget][ixx]){
															groupLock[gtarget] = Remove(groupLock[gtarget],groupLock[gtarget][ixx])
														}
													}
												}
												cloudget = []string{}
											}
											}
											saveJson()
											for i := range myassist{
												target := string(myassist[i][:33])
												fmt.Println(target)
												if target != myself{
													if nothingInMyContacts(target){
														time.Sleep(1 * time.Second)
														fmt.Println(target)
														AddContactByMid(target)
													}
												}
											}
										}else{SendText(to, "♪ Already exist")}
									}
								}else if strings.HasPrefix(strings.ToLower(looping[cmd]),"r3ass:"){
									if uncontains(myadmin,sender) || contains(mystaff,sender){
										result := strings.Split((text),":")
										result2 := result[1] +":"+ result[2]
										if uncontains(myassist,result2){
											myassist = append(myassist,result2)
											zxTeam = append(zxTeam,result2)
											zV3 = result2
											saveJson()
											if nothingInMyContacts(result[1]){
												time.Sleep(1 * time.Second)
												AddContactByMid(result[1])
											}
											for i := range myassist[2]{
												err := exec.Command("bash", "-c", "cd zxLib&&./asv3 "+argsRaw[1]+" "+strconv.Itoa(i+2)+" "+port).Start()
												if err!=nil{fmt.Println(err)}
												SendText(to, "♪ Success running AssistV3\n♪ Auth :\n"+result2)
												break
											}
											getReady := GetGroupsJoined()
											cloudtim := []string{}
											cloudget := []string{}
											for cu := range myassist{
												if uncontains(myteam, myassist[cu][:33]){
													cloudtim = append(cloudtim,myassist[cu][:33])
													myteam = append(myteam,myassist[cu][:33])
												}
											}
											for in := range getReady{
												gtarget := getReady[in]
												checkin := GetGroup(gtarget).Members
												for ui := range checkin{
													cloudget = append(cloudget,checkin[ui].Mid)
												}
												_, found := groupLock[gtarget]
												if found == false{
												for ix := range checkin{
													if contains(cloudtim,checkin[ix].Mid){
														if uncontains(groupLock[gtarget],checkin[ix].Mid){
															groupLock[gtarget] = append(groupLock[gtarget],checkin[ix].Mid)
														}
													}
												}
											}else{
												if len(groupLock[gtarget]) == 0{
													delete(groupLock,gtarget)
												}else{
													for ixx := range groupLock[gtarget]{
														if uncontains(cloudget,groupLock[gtarget][ixx]){
															groupLock[gtarget] = Remove(groupLock[gtarget],groupLock[gtarget][ixx])
														}
													}
												}
												cloudget = []string{}
											}
											}
											saveJson()
											for i := range myassist{
												target := string(myassist[i][:33])
												fmt.Println(target)
												if target != myself{
													if nothingInMyContacts(target){
														time.Sleep(1 * time.Second)
														fmt.Println(target)
														AddContactByMid(target)
													}
												}
											}
										}else{SendText(to, "♪ Already exist")}
									}
								}else if strings.HasPrefix(strings.ToLower(looping[cmd]),"r4ass:"){
									if uncontains(myadmin,sender) || contains(mystaff,sender){
										result := strings.Split((text),":")
										result2 := result[1] +":"+ result[2]
										if uncontains(myassist,result2){
											myassist = append(myassist,result2)
											zxTeam = append(zxTeam,result2)
											zV4 = result2
											saveJson()
											if nothingInMyContacts(result[1]){
												time.Sleep(1 * time.Second)
												AddContactByMid(result[1])
											}
											for i := range myassist{
												err := exec.Command("bash", "-c", "cd zxLib&&./asv4 "+argsRaw[1]+" "+strconv.Itoa(i+3)+" "+port).Start()
												if err!=nil{fmt.Println(err)}
												SendText(to, "♪ Success running AssistV4\n♪ Auth :\n"+result2)
												break
											}
											getReady := GetGroupsJoined()
											cloudtim := []string{}
											cloudget := []string{}
											for cu := range myassist{
												if uncontains(myteam, myassist[cu][:33]){
													cloudtim = append(cloudtim,myassist[cu][:33])
													myteam = append(myteam,myassist[cu][:33])
												}
											}
											for in := range getReady{
												gtarget := getReady[in]
												checkin := GetGroup(gtarget).Members
												for ui := range checkin{
													cloudget = append(cloudget,checkin[ui].Mid)
												}
												_, found := groupLock[gtarget]
												if found == false{
												for ix := range checkin{
													if contains(cloudtim,checkin[ix].Mid){
														if uncontains(groupLock[gtarget],checkin[ix].Mid){
															groupLock[gtarget] = append(groupLock[gtarget],checkin[ix].Mid)
														}
													}
												}
											}else{
												if len(groupLock[gtarget]) == 0{
													delete(groupLock,gtarget)
												}else{
													for ixx := range groupLock[gtarget]{
														if uncontains(cloudget,groupLock[gtarget][ixx]){
															groupLock[gtarget] = Remove(groupLock[gtarget],groupLock[gtarget][ixx])
														}
													}
												}
												cloudget = []string{}
											}
											}
											saveJson()
											for i := range myassist{
												target := string(myassist[i][:33])
												fmt.Println(target)
												if target != myself{
													if nothingInMyContacts(target){
														time.Sleep(1 * time.Second)
														fmt.Println(target)
														AddContactByMid(target)
													}
												}
											}
										}else{SendText(to, "♪ Already exist")}
									}
								}else if strings.HasPrefix(strings.ToLower(looping[cmd]),"r5ass:"){
									if uncontains(myadmin,sender) || contains(mystaff,sender){
										result := strings.Split((text),":")
										result2 := result[1] +":"+ result[2]
										if uncontains(myassist,result2){
											myassist = append(myassist,result2)
											zxTeam = append(myassist,result2)
											zV5 = result2
											saveJson()
											if nothingInMyContacts(result[1]){
												time.Sleep(1 * time.Second)
												AddContactByMid(result[1])
											}
											for i := range myassist{
												err := exec.Command("bash", "-c", "cd zxLib&&./asv5 "+argsRaw[1]+" "+strconv.Itoa(i+4)+" "+port).Start()
												if err!=nil{fmt.Println(err)}
												SendText(to, "♪ Success running AssistV5\n♪ Auth :\n"+result2)
												break
											}
											getReady := GetGroupsJoined()
											cloudtim := []string{}
											cloudget := []string{}
											for cu := range myassist{
												if uncontains(myteam, myassist[cu][:33]){
													cloudtim = append(cloudtim,myassist[cu][:33])
													myteam = append(myteam,myassist[cu][:33])
												}
											}
											for in := range getReady{
												gtarget := getReady[in]
												checkin := GetGroup(gtarget).Members
												for ui := range checkin{
													cloudget = append(cloudget,checkin[ui].Mid)
												}
												_, found := groupLock[gtarget]
												if found == false{
												for ix := range checkin{
													if contains(cloudtim,checkin[ix].Mid){
														if uncontains(groupLock[gtarget],checkin[ix].Mid){
															groupLock[gtarget] = append(groupLock[gtarget],checkin[ix].Mid)
														}
													}
												}
											}else{
												if len(groupLock[gtarget]) == 0{
													delete(groupLock,gtarget)
												}else{
													for ixx := range groupLock[gtarget]{
														if uncontains(cloudget,groupLock[gtarget][ixx]){
															groupLock[gtarget] = Remove(groupLock[gtarget],groupLock[gtarget][ixx])
														}
													}
												}
												cloudget = []string{}
											}
											}
											saveJson()
											for i := range myassist{
												target := string(myassist[i][:33])
												fmt.Println(target)
												if target != myself{
													if nothingInMyContacts(target){
														time.Sleep(1 * time.Second)
														fmt.Println(target)
														AddContactByMid(target)
													}
												}
											}
										}else{SendText(to, "♪ Already exist")}
									}
								}else if strings.HasPrefix(strings.ToLower(looping[cmd]),"r6ass:"){
									if uncontains(myadmin,sender) || contains(mystaff,sender){
										result := strings.Split((text),":")
										result2 := result[1] +":"+ result[2]
										if uncontains(myassist,result2){
											myassist = append(myassist,result2)
											zxTeam = append(zxTeam,result2)
											zV6 = result2
											saveJson()
											if nothingInMyContacts(result[1]){
												time.Sleep(1 * time.Second)
												AddContactByMid(result[1])
											}
											for i := range myassist{
												err := exec.Command("bash", "-c", "cd zxLib&&./asv6 "+argsRaw[1]+" "+strconv.Itoa(i+5)+" "+port).Start()
												if err!=nil{fmt.Println(err)}
												SendText(to, "♪ Success running AssistV6\n♪ Auth :\n"+result2)
												break
											}
											getReady := GetGroupsJoined()
											cloudtim := []string{}
											cloudget := []string{}
											for cu := range myassist{
												if uncontains(myteam, myassist[cu][:33]){
													cloudtim = append(cloudtim,myassist[cu][:33])
													myteam = append(myteam,myassist[cu][:33])
												}
											}
											for in := range getReady{
												gtarget := getReady[in]
												checkin := GetGroup(gtarget).Members
												for ui := range checkin{
													cloudget = append(cloudget,checkin[ui].Mid)
												}
												_, found := groupLock[gtarget]
												if found == false{
												for ix := range checkin{
													if contains(cloudtim,checkin[ix].Mid){
														if uncontains(groupLock[gtarget],checkin[ix].Mid){
															groupLock[gtarget] = append(groupLock[gtarget],checkin[ix].Mid)
														}
													}
												}
											}else{
												if len(groupLock[gtarget]) == 0{
													delete(groupLock,gtarget)
												}else{
													for ixx := range groupLock[gtarget]{
														if uncontains(cloudget,groupLock[gtarget][ixx]){
															groupLock[gtarget] = Remove(groupLock[gtarget],groupLock[gtarget][ixx])
														}
													}
												}
												cloudget = []string{}
											}
											}
											saveJson()
											for i := range myassist{
												target := string(myassist[i][:33])
												fmt.Println(target)
												if target != myself{
													if nothingInMyContacts(target){
														time.Sleep(1 * time.Second)
														fmt.Println(target)
														AddContactByMid(target)
													}
												}
											}
										}else{SendText(to, "♪ Already exist")}
									}
								}else if strings.HasPrefix(strings.ToLower(looping[cmd]),"banned"){
									 mentions := mentions{}
									 json.Unmarshal([]byte(op.Message.ContentMetadata["MENTION"]), &mentions)
									 for _, mention := range mentions.MENTIONEES{
											 appendBl(mention.Mid)
									 }
									 saveJson()
									 SendText(to, "♪ Added to Banned list")
								}else if strings.HasPrefix(strings.ToLower(looping[cmd]),"unbanned"){
									 mentions := mentions{}
									 json.Unmarshal([]byte(op.Message.ContentMetadata["MENTION"]), &mentions)
									 for _, mention := range mentions.MENTIONEES{
											 removeBl(mention.Mid)
									 }
									 saveJson()
									 SendText(to, "♪ Removed from Banned list")
								}else if strings.HasPrefix(strings.ToLower(looping[cmd]),"flood"){
									 mentions := mentions{}
									 json.Unmarshal([]byte(op.Message.ContentMetadata["MENTION"]), &mentions)
									 for _, mention := range mentions.MENTIONEES{
										   time.Sleep(70 * time.Millisecond)
											 AddContactByMid(mention.Mid)
									 }
									 for _, mention := range mentions.MENTIONEES{
													DeleteOtherFromChat(to, []string{mention.Mid})
													InviteIntoChat(to, []string{mention.Mid})
													CancelChatInvitation(to, []string{mention.Mid})
										}
					}else if strings.HasPrefix(strings.ToLower(looping[cmd]),"/"){
						 result := strings.Split((op.Message.Text),"/")
						 SendText(to, result[1])
						 broadcast("say_"+to+" "+result[1])
					}else if strings.ToLower(looping[cmd]) == "stabilizer on"{
						stabilizer = 1
						saveJson()
						SendText(to, "♪ Stabilizer is activated")
					}else if strings.ToLower(looping[cmd]) == "stabilizer off"{
						stabilizer = 0
						saveJson()
						SendText(to, "♪ Stabilizer is unactivated")
					}else if strings.ToLower(looping[cmd]) == "clearall"{
						getReady := GetGroupsJoined()
						for in := range getReady{
							gtarget := getReady[in]
							checkin := GetGroup(gtarget).Members
							if len(groupLock[gtarget]) == 0{
								delete(groupLock,gtarget)
							}else{
								for ui := range checkin{
									groupLock[gtarget] = Remove(groupLock[gtarget],groupLock[gtarget][ui])
								}
							}
							saveJson()
							SendText(to, "♪ Group Lock cleared.")
						}
					}else if strings.ToLower(looping[cmd]) == "reset"{
						myassist = []string{}
						saveJson()
						broadcast("loadjson")
						SendText(to, "♪ Assist data has ben reset")
					}else if strings.ToLower(looping[cmd]) == "reset2"{
						groupLock = make(map[string][]string)
						zbans = []string{}
						saveJson()
						broadcast("loadjson")
						SendText(to, "♪ All data has ben reset")
					}else if strings.ToLower(looping[cmd]) == "blockinvite on"{
						 proInvite[to] = 1
						 SendText(to, "♪ Group invite is protected")
					}else if strings.ToLower(looping[cmd]) == "blockinvite off"{
						 delete(proInvite,to)
						 SendText(to, "♪ Group invite is unprotected")
					}else if strings.ToLower(looping[cmd]) == "blockurl on"{
						 proQr[to] = 1
						 saveJson()
						 SendText(to, "♪ Group url is protected")
					}else if strings.ToLower(looping[cmd]) == "blockurl off"{
						 delete(proQr,to)
						 saveJson()
						 SendText(to, "♪ Group url is unprotected")
					}else if strings.ToLower(looping[cmd]) == "blockname on"{
						 proName[to] = 1
						 Gname := GetGroup(op.Message.To)
						 saveGname[to] = Gname.Name
						 saveJson()
						 SendText(to, "♪ Group name is protected")
					}else if strings.ToLower(looping[cmd]) == "blockname off"{
						 delete(saveGname,to)
						 delete(proName,to)
						 saveJson()
						 SendText(to, "♪ Group name is unprotected")
					}else if strings.ToLower(looping[cmd]) == "purgemode on"{
	 					autoPurge = 1
	 					saveJson()
						 broadcast("loadjson")
				 		SendText(to, "♪ Purgemode is activated")
				 	}else if strings.ToLower(looping[cmd]) == "purgemode off"{
				 		autoPurge = 0
				 		saveJson()
						 broadcast("loadjson")
				 		SendText(to, "♪ Purgemode is deactivated")
					}else if strings.ToLower(looping[cmd]) == "warmode on"{
	 					agresifMode = 1
	 					saveJson()
						 broadcast("loadjson")
				 		SendText(to, "♪ Warmode is activated")
				 	}else if strings.ToLower(looping[cmd]) == "warmode off"{
				 		agresifMode = 0
				 		saveJson()
						 broadcast("loadjson")
				 		SendText(to, "♪ Warmode is deactivated")
					}else if strings.ToLower(looping[cmd]) == "detectbl on"{
	 					detectBL = 1
	 					saveJson()
						 broadcast("loadjson")
				 		SendText(to, "♪ Detect BL is activated")
				 	}else if strings.ToLower(looping[cmd]) == "detectbl off"{
				 		detectBL = 0
				 		saveJson()
						 broadcast("loadjson")
				 		SendText(to, "♪ Detect BL is deactivated")
					}else if strings.ToLower(looping[cmd]) == "blockjoin on"{
				 		joinLock[to] = 1
				 		saveJson()
				 		SendText(to, "♪ Group join is protected")
				 	}else if strings.ToLower(looping[cmd]) == "blockjoin off"{
						 delete(joinLock,to)
				 		saveJson()
				 		SendText(to, "♪ Group join is unprotected")
					}else if strings.ToLower(looping[cmd]) == "welcome on"{
						 welcome[to] = 1
						 saveJson()
	 					SendText(to, "♪ Welcome is activated")
					}else if strings.ToLower(looping[cmd]) == "welcome off"{
						delete(welcome,to)
						saveJson()
						SendText(to, "♪ Welcome is deactivated")
					}else if strings.ToLower(looping[cmd]) == "antitag on"{
						denyTag[to] = 1
						saveJson()
						SendText(to, "♪ Group antitag is protected")
				 	}else if strings.ToLower(looping[cmd]) == "notag off"{
						delete(denyTag,to)
						saveJson()
						SendText(to, "♪ Group antitag is unprotected")
					}else if strings.ToLower(looping[cmd]) == "blockmember on"{
	 					 kickLock[to] = 1
	 					 saveJson()
	 					 SendText(to, "♪ Group member is protected")
					}else if strings.ToLower(looping[cmd]) == "blockmember off"{
						 delete(kickLock,to)
		 				saveJson()
		 				SendText(to, "♪ Group member is unprotected")
					}else if strings.ToLower(looping[cmd]) == "reader on"{
						checkRead[to] = 1
						gc := GetGroup(to)
						target := gc.Members
						targets:= []string{}
						for i:= range target{
							targets = append(targets,target[i].Mid)
						}
						readerTemp[to] = targets
						SendText(to, "♪ Group reader member activated")
				 	}else if strings.ToLower(looping[cmd]) == "reader off"{
						 delete(checkRead,to)
						 delete(readerTemp,to)
						 SendText(to, "♪ Group reader member deactivated")
					}else if strings.ToLower(looping[cmd]) == "here"{
						 gc := GetGroup(op.Message.To)
						 jumSquad := []string{}
						 for i:= range gc.Members{
							 for i2:= range myteam{
								 if gc.Members[i].Mid == myteam[i2]{
									 jumSquad = append(jumSquad, gc.Members[i].Mid)
								 }
							 }
						 }
						 SendText(to, "♪ "+strconv.Itoa(len(jumSquad)+1)+"/"+strconv.Itoa(len(myteam)+1)+" bots standby in here")
					}else if strings.ToLower(looping[cmd]) == "set"{
							 result := "╭────────────────\n├─•「 Bot Status set. 」\n│╭───────────────\n"
							 if denyTag[to] == 1{result += "│╰•【✓】Notag Mode\n"
							 }else{result += "│╰•【✘】Notag Mode\n"
							 }
							 if stabilizer == 1{result += "│╭•【✓】Stabilizer Mode\n"
							 }else{result += "│╭•【✘】Stabilizer Mode\n"
							 }
							 if welcome[to] == 1{result += "│╰•【✓】Welcome Msg\n"
							 }else{result += "│╰•【✘】Welcome Msg\n"
							 }
							 if checkRead[to] == 1{result += "│╭•【✓】Group Reader\n│╰──────────────\n"
							 }else{result += "│╭•【✘】Group Reader\n│╰──────────────\n"
							 }
							 if agresifMode == 1{result += "├─•「 Excellence Set. ️」\n│╭──────────────\n│╰•【✓】War Mode\n"
							 }else{result += "├─•「 Excellence Set. ️」\n│╭──────────────\n│╰•【✘】War Mode\n"
							 }
							 if detectBL == 1{result += "│╭•【✓】Detect Mode\n"
							 }else{result += "│╭•【✘】Detect Mode\n"
							 }
							 if autoPurge == 1{result += "│╰•【✓】Purge Mode\n"
							 }else{result += "│╰•【✘】Purge Mode\n"
							 }
							 if proInvite[to] == 1{result += "│╭•【✓】Block Invite\n"
							 }else{result += "│╭•【✘】Block Invite\n"
							 }
							 if proQr[to] == 1{result += "│╰•【✓】Block Qr\n"
							 }else{result += "│╰•【✘】Block Qr\n"
							 }
							 if joinLock[to] == 1{result += "│╭•【✓】Block Join\n"
							 }else{result += "│╭•【✘】Block Join\n"
							 }
							 if proName[to] == 1{result += "│╰•【✓】Block GName\n"
							 }else{result += "│╰•【✘】Block GName\n"
							 }
							 if kickLock[to] == 1{result += "│╭•【✓】Block Member\n"
							 }else{result += "│╭•【✘】Block Member\n"
							 }
							 SendText(to, result+"│╰───────────────\n├─•「 Z x s ⌬ Since ²k²¹ 」\n╰────────────────")
						}else if strings.HasPrefix(strings.ToLower(looping[cmd]),"upheader"){
							if myowner == string(sender){
								 result := strings.Split((op.Message.Text)," ")
								 helpHeader = result[1]
								 saveJson()
								 SendText(to, "♪ Header message updated")
							}
						}else if strings.HasPrefix(strings.ToLower(looping[cmd]),"setstay"){
							if uncontains(myadmin,sender) || contains(mystaff,sender){
								result := strings.Split((text)," ")
								x,_ := strconv.Atoi(result[1])
								zxBots = x
								SendText(to, "♪ The number of staybot has been set")
								broadcast("limiterbot_"+result[1])
							}
						 }else if strings.HasPrefix(strings.ToLower(looping[cmd]),"upsname"){
						        if myowner == string(sender){
									 result := strings.Split((op.Message.Text)," ")
									 sname = result[1]
									 saveJson()
									 SendText(to, "♪ Squad name updated")
								}
						 }
					}
				}
		}else if (op.Message.ContentType).String() == "STICKER"{
					if myowner == string(sender) || contains(mycreator,sender) || contains(myadmin, string(sender)) || contains(mystaff,sender){
						if getStickerRespon == 1{
							if myowner == string(sender) || contains(mycreator,sender){
								 stkid = op.Message.ContentMetadata["STKID"]
								 stkpkgid = op.Message.ContentMetadata["STKPKGID"]
								 saveJson()
								 getStickerRespon = 0
								 SendText(to, "♪ Respon by sticker updated")
							}
						}else if getStickerBye == 1{
							 if myowner == string(sender) || contains(mycreator,sender){
									stkid3 = op.Message.ContentMetadata["STKID"]
									stkpkgid3 = op.Message.ContentMetadata["STKPKGID"]
									saveJson()
									getStickerBye = 0
									SendText(to, "♪ Bye by sticker updated")
							 }
						}else if getStickerUnban == 1{
							 if myowner == string(sender) || contains(mycreator,sender){
									stkid4 = op.Message.ContentMetadata["STKID"]
									stkpkgid4 = op.Message.ContentMetadata["STKPKGID"]
									saveJson()
									getStickerUnban = 0
									SendText(to, "♪ Unban by sticker updated")
							 }
						}else if getStickerKick == 1{
							 if myowner == string(sender) || contains(mycreator,sender){
									stkid2 = op.Message.ContentMetadata["STKID"]
									stkpkgid2 = op.Message.ContentMetadata["STKPKGID"]
									saveJson()
									getStickerKick = 0
									SendText(to, "♪ Kick by sticker updated")
							 }
						}else if op.Message.ContentMetadata["STKID"] == stkid && op.Message.ContentMetadata["STKPKGID"] == stkpkgid{
							_, found := groupLock[to]
							if found == false{SendText(to, MessageRespon)
								}else{
									if len(groupLock[to]) > 0{
										SendText(to, MessageRespon)
										targetNumber = 0
										targetCommand = "ready"
										singletarget = string(groupLock[to][0])
										broadcast2(groupLock[to][0],"respon_"+to)
									}else{SendText(to, MessageRespon)}
								}
						 }else if op.Message.ContentMetadata["STKID"] == stkid2 && op.Message.ContentMetadata["STKPKGID"] == stkpkgid2{
							 _, found := op.Message.ContentMetadata["message_relation_server_message_id"]
 						   if found == true{
								 for i := range msgTemp{
									 if contains(msgTemp[i],op.Message.ContentMetadata["message_relation_server_message_id"]){
										 if !fullAccess(i){
											 DeleteOtherFromChat(to,[]string{i})
											 break
										 }
									 }
								 }
							 }
						 }else if op.Message.ContentMetadata["STKID"] == stkid3 && op.Message.ContentMetadata["STKPKGID"] == stkpkgid3{
							 if uncontains(mystaff,sender){
								 delete(readerTemp,to)
								 delete(checkRead,to)
				 				 delete(proInvite,to)
				 				 delete(proName,to)
				 				 delete(proQr,to)
				 				 delete(joinLock,to)
				 				 delete(denyTag,to)
				 				 delete(kickLock,to)
				 				 delete(saveGname,to)
								  delete(groupLock,to)
				 				 saveJson()
								  SendText(to, msgbye)
				 				 LeaveGroup(to)
							 }
						 }else if op.Message.ContentMetadata["STKID"] == stkid4 && op.Message.ContentMetadata["STKPKGID"] == stkpkgid4{
							 if uncontains(mystaff,sender){
								 if len(bans) == 0{
									 SendText(to, "nobody is banned")
								 }else{
									 msgchn:= fmt.Sprintf(MessageBan,len(bans))
									 SendText(to, msgchn)
									 bans = []string{}
									 saveJson()
								 }
							 }
						 }
					}
		}else if (op.Message.ContentType).String() == "CONTACT"{
			fmt.Println(op)
			if myowner == sender || contains(mycreator,sender) || contains(myadmin,sender){
				objmid := op.Message.ContentMetadata["mid"]
				if promoteadmin[to] == 1{
					if uncontains(myadmin,sender){
						if uncontains(myadmin,objmid){
							if objmid != myself{
								myadmin = append(myadmin, objmid)
								if nothingInMyContacts(objmid){
									time.Sleep(1 * time.Second)
									AddContactByMid(objmid)
								}
							}
							saveJson()
							SendText(to, "♪ Contact Success added to admin, type stop to stop this function!")
						}
					}
				}else if promotestaff[to] == 1{
					if uncontains(mystaff,objmid){
						if objmid != myself{
							mystaff = append(mystaff, objmid)
							if nothingInMyContacts(objmid){
								time.Sleep(1 * time.Second)
								AddContactByMid(objmid)
							}
						}
						saveJson()
						SendText(to, "♪ Contact Success added to staff, type stop to stop this function!")
					}
				}else if demoteadmin[to] == 1{
					if uncontains(myadmin,sender){
						if uncontains(myadmin,objmid){
							if objmid != myself{
								mystaff = append(mystaff, objmid)
								if nothingInMyContacts(objmid){
									time.Sleep(1 * time.Second)
									AddContactByMid(objmid)
								}
							}
							saveJson()
							SendText(to, "♪ Contact demoted from admin, type stop to stop this function!")
						}
					}
				}else if demotestaff[to] == 1{
					if uncontains(mystaff,objmid){
						if objmid != myself{
							mystaff = append(mystaff, objmid)
							if nothingInMyContacts(objmid){
								time.Sleep(1 * time.Second)
								AddContactByMid(objmid)
							}
						}
						saveJson()
						SendText(to, "♪ Contact demoted from staff, type stop to stop this function!")
					}
				}
			}
		}else if (op.Message.ContentType).String() == "IMAGE"{
						if updatePicture == 1{
							 if myowner == string(sender) || contains(mycreator,sender){
									callProfile(op.Message.ID,"picture")
									updatePicture = 0
									SendText(to, "♪ Picture updated")
							 }
						}
						if updatePicture2 == 1{
							 if myowner == string(sender) || contains(mycreator,sender){
								  for i := range targetbc{
										broadcast2(targetbc[i],"changepp_"+op.Message.ID)
									}
									targetbc = []string{}
									updatePicture2 = 0
									SendText(to, "♪ Picture updated")
							 }
						}
						if updateCover == 1{
							 if myowner == string(sender) || contains(mycreator,sender){
									callProfile(op.Message.ID,"cover")
									updateCover = 0
									SendText(to, "♪ Cover updated")
							 }
						}
						if updateCover2 == 1{
							 if myowner == string(sender) || contains(mycreator,sender){
								  for i := range targetbc{
										broadcast2(targetbc[i],"changecv_"+op.Message.ID)
									}
									targetbc = []string{}
									updateCover2 = 0
									SendText(to, "♪ Cover updated")
							 }
						}

		}
		mentions := mentions{}
		json.Unmarshal([]byte(op.Message.ContentMetadata["MENTION"]), &mentions)
		for _, mention := range mentions.MENTIONEES{
			if contains(myteam,mention.Mid){
				if strings.Contains(text, commands[1]){
					if myowner == sender || contains(mycreator,sender){
						updatePicture2 = 1
						for _, taged := range mentions.MENTIONEES{
							targetbc = append(targetbc, taged.Mid)
						}
						SendText(to, "♪ Please send an image")
						break
					}
				}else if strings.Contains(text, commands[2]){
					if myowner == sender || contains(mycreator,sender){
						updateCover2 = 1
						for _, taged := range mentions.MENTIONEES{
							targetbc = append(targetbc, taged.Mid)
						}
						SendText(to, "♪ Please send an image")
						break
					}
				}else if strings.Contains(text, commands[3]){
					if myowner == sender || contains(mycreator,sender){
						 result := strings.Split(text," ")
						 for _, taged := range mentions.MENTIONEES{
							 broadcast2(taged.Mid,"changename_"+result[1])
						 }
						 SendText(to, "♪ Name updated")
					}
					break
				}else if strings.Contains(text, commands[4]){
					if myowner == sender || contains(mycreator,sender){
						 result := strings.Split(text," ")
						 for _, taged := range mentions.MENTIONEES{
							 broadcast2(taged.Mid,"changebio_"+result[1])
						 }
						 SendText(to, "♪ Bio updated")
					}
					break
				}
			}
		 }
	}else{
		if denyTag[to] == 1{
		   mentions := mentions{}
		   json.Unmarshal([]byte(op.Message.ContentMetadata["MENTION"]), &mentions)
		   for _, mention := range mentions.MENTIONEES{
			   if mention.Mid == myself{
					 if !fullAccess(sender){
						 DeleteOtherFromChat(to, []string{sender})
             appendBl(sender)
 				     break
					 }

					}
		    }
		}
	}
}
}
}
//start
func main(){
	installer()
	cleardns()
	loadJson()
	connection, err := net.Listen("tcp", port)
	if err != nil { fmt.Println(err)}
	connected := connection
	defer connected.Close()
	go func() {
		for{
			cont, err := connected.Accept()
			if err != nil{
				fmt.Println(err)
			}
			go handleConnection(cont)
		}
	}()
	addAsFriendContact(myowner)
	profile := GetProfile()
	SendText(myowner, "• Type Bots : Captains\n• App. Name :\n   "+zxApp+"\n• Bot Name : "+profile.DisplayName+"\n• Bot ID : "+profile.Mid+"\n• Status : Not Banned\n• Developer : Rey Zeus")
	cpu = runtime.NumCPU()
	fmt.Println("\033[33m\n\n──「 Welcome To GoLang Bots 」──\n\033[39m")
	rev := getLastOpRevision()
	myself = string(profile.Mid)
	CheckExpired()
	fmt.Printf("\033[33m• IP Address: %s\n• Developer : Rey Zeus\n• Bot Name  : %s\n• Bot ID    : %s\n• Vps Proc. : %d core\n• Expired In: %d day\n\n─── Bot Golang Success Login ───\n\033[39m",myip,profile.DisplayName,profile.Mid,cpu,duedatecount)
	go speedStabilizer()
	go autoUnlock()
	for{
		fetch := fetchOperations(rev,1)
		looper := len(fetch)
		if looper > 0{
			ops := fetch[0]
			command(ops)
			revs := ops.Revision
			rev = MaxRevision(rev, revs)
		}
	}
}
